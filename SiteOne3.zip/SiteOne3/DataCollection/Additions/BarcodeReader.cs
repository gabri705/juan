using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Com.Honeywell.Aidc
{
    public partial class BarcodeReader
    {
        private WeakReference _dispatcher;

        public void Initialize()
        {
            AddBarcodeListener(EventDispatcher);
        }

        BarcodeReaderEventDispatcher EventDispatcher
        {
            get
            {
                if (_dispatcher == null || !_dispatcher.IsAlive)
                {
                    var d = new BarcodeReaderEventDispatcher();

                    _dispatcher = new WeakReference(d);
                }

                return _dispatcher.Target as BarcodeReaderEventDispatcher;
            }
        }

        public event Action<BarcodeReadEvent> BarcodeScanned
        {
            add
            {
                EventDispatcher.BarcodeScanned += value;
            }

            remove
            {
                EventDispatcher.BarcodeScanned -= value;
            }
        }

        public event Action<BarcodeFailureEvent> BarcodeScanFailed
        {
            add
            {
                EventDispatcher.BarcodeScanFailed += value;
            }

            remove
            {
                EventDispatcher.BarcodeScanFailed -= value;
            }
        }
    }
}