using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using static Com.Honeywell.Aidc.BarcodeReader;

namespace Com.Honeywell.Aidc
{
    internal partial class BarcodeReaderEventDispatcher : Java.Lang.Object, IBarcodeListener
    {
        internal Action<BarcodeReadEvent> BarcodeScanned;
        internal Action<BarcodeFailureEvent> BarcodeScanFailed;

        public void OnBarcodeEvent(BarcodeReadEvent e)
        {
            var h = BarcodeScanned;
            h?.Invoke(e);
        }

        public void OnFailureEvent(BarcodeFailureEvent e)
        {
            var h = BarcodeScanFailed;
            h?.Invoke(e);
        }
    }
}