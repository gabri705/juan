using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Com.Honeywell.Aidc;
using static Com.Honeywell.Aidc.AidcManager;

namespace Com.Honeywell.Aidc
{
    internal partial class AidcManagerEventDispatcher : Java.Lang.Object, ICreatedCallback
    {
        internal Action<AidcManager> Created;

        public void OnCreated(AidcManager manager)
        {
            var h = Created;

            h?.Invoke(manager);
        }
    }
}