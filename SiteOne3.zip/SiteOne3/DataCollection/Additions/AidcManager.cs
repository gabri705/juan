using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Com.Honeywell.Aidc
{
    public partial class AidcManager
    {
        private static WeakReference _dispatcher;

        static AidcManagerEventDispatcher EventDispatcher
        {
            get
            {
                if (_dispatcher == null || !_dispatcher.IsAlive)
                {
                    var d = new AidcManagerEventDispatcher();

                    _dispatcher = new WeakReference(d);
                }

                return _dispatcher.Target as AidcManagerEventDispatcher;
            }
        }

        public static event Action<AidcManager> Created
        {
            add
            {
                EventDispatcher.Created += value;
            }

            remove
            {
                EventDispatcher.Created -= value;
            }
        }

        public static void Create(Context context)
        {
            Create(context, EventDispatcher);
        }
    }
}