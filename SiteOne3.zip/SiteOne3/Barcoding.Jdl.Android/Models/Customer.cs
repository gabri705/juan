﻿using Barcoding.Jdl.Android.Helpers;
using Newtonsoft.Json;
using System;

namespace Barcoding.Jdl.Android.Models
{
    public class Customer
    {
        public Guid AddressID { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public Guid CustTreeNodeId { get; set; }
        public string CustomerNumber { get; set; }
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
        [JsonConverter(typeof(BoolConverter))]
        public bool PONumberRequired { get; set; }
        public string PostalCode { get; set; }
        public string StateCode { get; set; }
    }
}