using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Barcoding.Jdl.Android.Models
{
    public class UpdateOrderObject
    {
        public Guid OrderId { get; set; }
        public Guid? AttentionToNodeID { get; set; }
        public string AttentionTo { get; set; }
        public Guid? AttentionToPhoneID { get; set; }
        public Guid? DeliveryAddressID { get; set; }
        public int? ShipmentServiceModeID { get; set; }
        public string SpecialInstructions { get; set; }
        public bool PendingATP { get; set; }
        public string WarehouseDesc { get; set; }
        public string WarehouseCode { get; set; }
        public string ShipmentTypeDesc { get; set; }
        public OrderShipmentType OrderShipmentType { get; set; }
        public decimal DiscountTotal { get; set; }
        public Guid? GeoCodeShipToAddressID { get; set; }
        public Guid? GeoCodeShipFromAddressID { get; set; }
        public Guid? GeoCodeOrderAcceptAddressID { get; set; }
        public decimal? TaxableAmount { get; set; }
        public decimal NonTaxableAmount { get; set; }
        public string CreditOverrideCode { get; set; }
        public string OrderNumber { get; set; }
        public bool IsInvoiced { get; set; }
        public decimal? TaxTotal { get; set; }
        public string DestinationState { get; set; }
        public string DestinationZip { get; set; }
        public int? ResponsibleSalesAreaID { get; set; }
        public int? TruckTypeID { get; set; }
        public int? TruckOptionID { get; set; }
        public decimal? TruckOptionAmt { get; set; }
        public decimal? TruckOptionTaxAmt { get; set; }
        public decimal? TruckOptionTaxRate { get; set; }
        public int? CarrierID { get; set; }
        public int? CarrierServiceID { get; set; }
        public decimal? NumberOfPallets { get; set; }
        public decimal? FreightAmt { get; set; }
        public decimal? Weight { get; set; }
        public string CarrierName { get; set; }
        public string BOLNumber { get; set; }
        public decimal? FreightTaxAmt { get; set; }
        public decimal? FreightTaxRate { get; set; }
        public decimal? MillTaxTotal { get; set; }
        public string TaxAuthority { get; set; }
        public int? WarehouseSupplyChainNodeID { get; set; }
        public int? TransmissionMethodID { get; set; }
        public string TransmissionFaxNumber { get; set; }
        public string TransmissionEmailAddress { get; set; }
        public bool? ShipComplete { get; set; }
        public string CrossStreets { get; set; }
        public string VendorQuoteNumber { get; set; }
        public string VendorQuotedBy { get; set; }
        public decimal? VendorQuoteAmount { get; set; }
        public string FreightQuoteNumber { get; set; }
        public string FreightQuotedBy { get; set; }
        public decimal? FreightQuoteAmount { get; set; }
        public Guid? NurserySalespersonCustTreeNodeID { get; set; }
        public string BillingComment { get; set; }
        public decimal? UnbilledFreight { get; set; }
        public decimal? BilledFreight { get; set; }
        public int ProductTypeID { get; set; }
        public decimal? EstimatedFreightAmt { get; set; }
        public bool IsTcs { get; set; }
        public bool NurseryBillingApprovalExists { get; set; }
        public bool NurseryVendorInvoiceExists { get; set; }
        public bool NurseryFreightInvoiceExists { get; set; }
        public bool NurserySignedPODExists { get; set; }
        public int? CommissionSalesAreaID { get; set; }
        public Guid? DriverID { get; set; }
        public string DriverDisplayName { get; set; }
        public CustomerInfoDto BillingCustomerInfo { get; set; }
        public CustomerInfoDto OrderingCustomerInfo { get; set; }
        public Guid OrderHeaderId { get; set; }
        public int? ModfUserId { get; set; }
        public decimal? PstTaxTotal { get; set; }
        public decimal? GstTaxTotal { get; set; }
        public decimal? HstTaxTotal { get; set; }
        public ShipmentStatusType ShipmentStatus { get; set; }
        public byte[] SignatureBytes { get; set; }
        public string SignatureName { get; set; }
        public string Signature { get; set; }
        public string EnteredByName { get; set; }
        public List<OrderDetailDto> OrderDetailDtos { get; set; }
        public AddressInfoDto DeliveryAddress { get; set; }
        public PhoneInfoDto AttentionToPhone { get; set; }
        public int? OrderShipmentCount { get; set; }
        public bool OnCreditHold { get; set; }
    }

    public enum OrderShipmentType
    {
        FuturePickUp = 1,
        DirectShip = 2,
        PickUp = 3,
        StoreDelivery = 4
    }

    public class CustomerInfoDto
    {
        public Guid Id { get; set; }
        public string CustomerNumber { get; set; }
        public string Name { get; set; }
        public AddressInfoDto AddressInfo { get; set; }
        public string PhoneNumber { get; set; }
    }

    public class AddressInfoDto
    {
        public Guid AddressId { get; set; }
        public string Street1 { get; set; }
        public string Street2 { get; set; }
        public string City { get; set; }
        public string StateCode { get; set; }
        public string PostalCode { get; set; }
        public string AddressCode { get; set; }
    }

    public enum ShipmentStatusType
    {
        Complete = 1,
        PendingCheckout = 2,
        Future = 3,
        Reserved = 4
    }

    public class OrderDetailDto
    {
        public decimal QtyOpen { get; set; }
        public Guid OrderShipmentID { get; set; }
        public Guid OrderDetailID { get; set; }
        public decimal? QtyShipped { get; set; }
        public decimal? QtyAllocated { get; set; }
        public decimal OrigQtyAllocated { get; set; }
        public decimal? QtyPicked { get; set; }
        public decimal OrigQtyOrdered { get; set; }
        public decimal? OrigQtyPicked { get; set; }
        public decimal? QtyCancelled { get; set; }
        public decimal? OrigQtyCancelled { get; set; }
        public decimal? QtyBackorder { get; set; }
        public decimal QtyOrdered { get; set; }
        public decimal? FreightAmt { get; set; }
        public decimal? QtyAvailable { get; set; }
        public bool? IsRegistered { get; set; }
        public decimal TaxAmt { get; set; }
        public decimal MillTaxAmt { get; set; }
        public decimal? TaxRate { get; set; }
        public bool? Taxable { get; set; }
        public decimal? QtyReplenished { get; set; }
        public string SourceWarehouseDesc { get; set; }
        public string VendorPO { get; set; }
        public bool? PurchaseOrderCreated { get; set; }
        public bool? RoutingOverridden { get; set; }
        public int? SourceSupplyChainNodeID { get; set; }
        public decimal QtyInvoiced { get; set; }
        public decimal? ReplacementCost { get; set; }
        public int? LineNumber { get; set; }
        public decimal? QtyOnHand { get; set; }
        public decimal Qty { get; set; }
        public int? PriceMethodID { get; set; }
        public string PriceMethodDesc { get; set; }
        public decimal? FloorPrice { get; set; }
        public decimal? TopListPrice { get; set; }
        public decimal? ItemCost { get; set; }
        public decimal? ActualPriceLastPaid { get; set; }
        public string ProductDesc { get; set; }
        public string ItemNumber { get; set; }
        public bool IsMiscItem { get; set; }
        public bool? LineIsFixed { get; set; }
        public decimal OriginalUnitPrice { get; set; }
        public decimal ActualUnitPrice { get; set; }
        public decimal? DiscountAmount { get; set; }
        public decimal DiscountedUnitPrice { get; set; }
        public decimal? OriginalPricePoint { get; set; }
        public decimal? ActualPricePoint { get; set; }
        public int? PriceOverrideReasonID { get; set; }
        public string PriceOverrideReasonText { get; set; }
        public bool? IsRUPItem { get; set; }
        public string SeedLot { get; set; }
        public string CouponCode { get; set; }
        public Guid? CouponID { get; set; }
        public string SerialNumber { get; set; }
        public string PriceListCode { get; set; }
        public bool IsSerialized { get; set; }
        public string InventoryUOM { get; set; }
        public Guid? BOGOParent_OrderDetailID { get; set; }
        public Guid? BOGOChild_OrderDetailID { get; set; }
        public decimal? BOGOMaxFree { get; set; }
        public string TaxOverride { get; set; }
        public decimal? ItemWeight { get; set; }
        public bool CaliforniaLicenseRequired { get; set; }
        public string CreditMemoReasonCode { get; set; }
        public bool? IsVendorItem { get; set; }
        public string InventoryLookupUrl { get; set; }
        public string ManufacturerCode { get; set; }
        public Guid? ProgramPriceDiscountID { get; set; }
        public Guid? SerialNumberID { get; set; }
        public int? MatrixSourceID { get; set; }
        public string ItemNote { get; set; }
        public string Cases { get; set; }
        public int? SkuID { get; set; }
        public bool? ExceptionalSale { get; set; }
        public bool? CanDirectShip { get; set; }
        public bool? PrimaryVendorIsTCS { get; set; }
        public bool? SupplyingVendorIsTCS { get; set; }
        public int? GLCodeID { get; set; }
        public string ProductLine { get; set; }
        public decimal? StandardCost { get; set; }
        public decimal? CostForGMPercent { get; set; }
        public decimal? QtyLost { get; set; }
        public string SkuDisplayString { get; set; }
        public bool ReasonRequired { get; set; }
        public bool InfiniteInventory { get; set; }
        public bool? SkuIsSelling { get; set; }
        public bool? IsPartialTcsExempt { get; set; }
        public bool Hazardous { get; set; }
        public bool? ProductAlert { get; set; }
        public int? PriceSpecialID { get; set; }
        public int? ModfUserId { get; set; }
        public bool? AllowDecimal { get; set; }
    }

    public class PhoneInfoDto
    {
        public Guid PhoneId { get; set; }
        public PhoneType PhoneType { get; set; }
        public string PhoneNumber { get; set; }
        public string Extension { get; set; }
        public bool Active { get; set; }
    }

    public enum PhoneType
    {
        Work = 1,
        Cell = 2,
        Home = 3,
        Fax = 4,
        Other = 5,
        SpeedDial = 6,
        DirectConnect = 7,
        VoiceMail = 8,
        Customer_Service = 9
    }
}