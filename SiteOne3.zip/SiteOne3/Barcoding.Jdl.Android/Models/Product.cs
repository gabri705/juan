﻿namespace Barcoding.Jdl.Android.Models
{
    public class Product
    {
        public string ItemDescription { get; set; }
        public string ItemNumber { get; set; }
        public decimal Price { get; set; }
        public decimal QtyAvailable { get; set; }
        public decimal QtyOnHand { get; set; }
        public decimal ReplacementCost { get; set; }
        public int SkuID { get; set; }
    }
}