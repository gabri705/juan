using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Barcoding.Jdl.Android.Models
{
    public class LineItem
    {
        public string ItemDescription { get; set; }
        public decimal ItemDiscount { get; set; }
        public string ItemNumber { get; set; }
        public decimal ListPrice { get; set; }
        public decimal NetPrice { get; set; }
        public decimal QtyAvailable { get; set; }
        public decimal QtyOnHand { get; set; }
        public decimal QtyOrdered { get; set; }
        public decimal ReplacementCost { get; set; }
        public int SkuID { get; set; }
        public decimal UnitPrice { get; set; }
    }
}