using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Barcoding.Jdl.Android.Models
{
    public class Branch
    {
        public string BranchName { get; set; }
        public string BranchNameRaw { get; set; }
        public string BranchNumber { get; set; }
        public string City { get; set; }
        public string Description { get; set; }
        public string DisplayName { get; set; }
        public double Distance { get; set; }
        public string Latitude { get; set; }
        public string Longitude { get; set; }
        public string PhoneNumber { get; set; }
        public string PostalCode { get; set; }
        public string StateCode { get; set; }
        public string Street { get; set; }
        public string Street2 { get; set; }
        public int SupplyChainNodeId { get; set; }
        public Guid AddressID { get; set; }
    }
}