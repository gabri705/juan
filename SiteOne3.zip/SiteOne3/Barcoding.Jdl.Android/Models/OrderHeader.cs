using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Barcoding.Jdl.Android.Models
{
    public class OrderHeader
    {
        public DateTime CreatedDate { get; set; }
        public string CustomerName { get; set; }
        public string CustomerNumber { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string OrderNumber { get; set; }
        public decimal TotalCost { get; set; }
        public Guid OrderId { get; set; }
        public string PONumber { get; set; }
    }
}