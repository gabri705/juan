using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;

namespace Barcoding.Jdl.Android.Helpers
{
    public class WaitHelper : IDisposable
    {
        public ProgressDialog Dialog { get; set; }

        public WaitHelper(Activity activity, string message = "Working...")
        {
            Dialog = new ProgressDialog(activity);
            Dialog.SetMessage(message);
            Dialog.Indeterminate = true;
            Dialog.SetCancelable(false);
            Dialog.Show();
        }

        public void Dispose()
        {
            Dialog.Dismiss();
            Dialog.Dispose();
        }
    }
}