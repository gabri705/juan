namespace Barcoding.Jdl.Android.Helpers
{
    public enum ProductSearchCriteria
    {
        ItemNumber,
        Description
    }
}