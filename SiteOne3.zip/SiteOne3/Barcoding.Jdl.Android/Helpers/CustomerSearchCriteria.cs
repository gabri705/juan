namespace Barcoding.Jdl.Android.Helpers
{
    public enum CustomerSearchCriteria
    {
        CustomerName,
        CustomerNumber,
        StreetAddress,
        City,
        State,
        PhoneNumber
    }
}