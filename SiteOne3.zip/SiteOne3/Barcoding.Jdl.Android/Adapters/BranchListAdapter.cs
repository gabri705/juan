using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Barcoding.Jdl.Android.Models;
using Android.Support.V7.Widget;
using Android.Graphics;

namespace Barcoding.Jdl.Android.Adapters
{
    public class BranchListAdapter : RecyclerView.Adapter
    {
        public delegate void CustomClickEventHandler(int position);
        public delegate void BranchListAdapterItemClickEventHandler(Branch branch);

        public class BranchViewHolder : RecyclerView.ViewHolder
        {
            public event CustomClickEventHandler Click;

            public View View { get; set; }
            public TextView BranchNumber { get; set; }
            public TextView BranchName { get; set; }
            public TextView PhoneNumber { get; set; }
            public TextView Street1 { get; set; }
            public TextView Street2 { get; set; }
            public TextView CityStateZip { get; set; }

            public BranchViewHolder(View view)
                : base(view)
            {
                View = view;

                View.Click += View_Click;
            }

            private void View_Click(object sender, EventArgs e)
            {
                var view = sender as View;

                if (Click != null)
                {
                    Click(this.LayoutPosition);
                }
            }
        }

        private List<Branch> _branches;
        private List<Branch> _filteredBranches;

        public event BranchListAdapterItemClickEventHandler ItemClick;

        public BranchListAdapter(List<Branch> branches)
        {
            _branches = branches;
            _filteredBranches = branches;
        }

        public override int ItemCount
        {
            get
            {
                return _filteredBranches != null ? _filteredBranches.Count() : 0;
            }
        }

        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
        {
            var viewHolder = holder as BranchViewHolder;

            var branch = _filteredBranches[position];

            if (position % 2 == 0)
            {
                viewHolder.View.SetBackgroundResource(Resource.Color.rowEven);
            }
            else
            {
                viewHolder.View.SetBackgroundResource(Resource.Color.rowOdd);
            }

            viewHolder.BranchName.Text = branch.BranchName;
            viewHolder.BranchNumber.Text = branch.BranchNumber;
            viewHolder.Street1.Text = branch.Street;
            viewHolder.Street1.Visibility = string.IsNullOrWhiteSpace(branch.Street) ? ViewStates.Gone : ViewStates.Visible;
            viewHolder.Street2.Text = branch.Street2;
            viewHolder.Street2.Visibility = string.IsNullOrWhiteSpace(branch.Street2) ? ViewStates.Gone : ViewStates.Visible;
            var zip = !string.IsNullOrWhiteSpace(branch.PostalCode) && branch.PostalCode.Length >= 5 ? branch.PostalCode.Substring(0, 5) : "";
            viewHolder.CityStateZip.Text = String.Format("{0}, {1} {2}", branch.City, branch.StateCode, zip);
            viewHolder.CityStateZip.Visibility = string.IsNullOrWhiteSpace(branch.City) || string.IsNullOrWhiteSpace(branch.StateCode) || string.IsNullOrWhiteSpace(branch.PostalCode) ? ViewStates.Gone : ViewStates.Visible;
            viewHolder.PhoneNumber.Text = branch.PhoneNumber;
            viewHolder.PhoneNumber.Visibility = string.IsNullOrWhiteSpace(branch.PhoneNumber) ? ViewStates.Gone : ViewStates.Visible;
        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            var view = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.BranchListItem, parent, false);

            var branchNumber = view.FindViewById<TextView>(Resource.Id.BranchNumber);
            var branchName = view.FindViewById<TextView>(Resource.Id.BranchName);
            var street1 = view.FindViewById<TextView>(Resource.Id.Street1);
            var street2 = view.FindViewById<TextView>(Resource.Id.Street2);
            var cityStateZip = view.FindViewById<TextView>(Resource.Id.CityStateZip);
            var phoneNumber = view.FindViewById<TextView>(Resource.Id.PhoneNumber);

            var holder = new BranchViewHolder(view) { BranchName = branchName, BranchNumber = branchNumber, PhoneNumber = phoneNumber, Street1 = street1, Street2 = street2, CityStateZip = cityStateZip };

            holder.Click += Item_Click;

            return holder;
        }

        private void Item_Click(int position)
        {
            if (ItemClick != null)
            {
                ItemClick(_filteredBranches.ElementAt(position));
            }
        }

        public void FilterItems(string filter)
        {
            _filteredBranches = string.IsNullOrWhiteSpace(filter) ? _branches : _branches.Where(b => (b.BranchName.ToUpper().Contains(filter.ToUpper()) || b.BranchNumber.ToUpper().Contains(filter.ToUpper()))).ToList();

            this.NotifyDataSetChanged();
        }
    }
}