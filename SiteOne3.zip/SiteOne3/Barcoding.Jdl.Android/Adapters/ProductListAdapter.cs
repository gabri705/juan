using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.Widget;
using Barcoding.Jdl.Android.Models;

namespace Barcoding.Jdl.Android.Adapters
{
    public class ProductListAdapter : RecyclerView.Adapter
    {
        public delegate void CustomClickEventHandler(int position);
        public delegate void ProductListAdapterItemClickEventHandler(Product product);

        public class ProductViewHolder : RecyclerView.ViewHolder
        {
            public event CustomClickEventHandler Click;

            public View View { get; set; }
            public TextView ItemNumber { get; set; }
            public TextView Description { get; set; }
            public TextView Price { get; set; }
            public TextView QtyOnHand { get; set; }
            public TextView QtyAvailable { get; set; }

            public ProductViewHolder(View view)
                : base(view)
            {
                View = view;

                View.Click += View_Click;
            }

            private void View_Click(object sender, EventArgs e)
            {
                var view = sender as View;

                if (Click != null)
                {
                    Click(this.LayoutPosition);
                }
            }
        }

        private List<Product> _products;
        public List<Product> Products
        {
            get
            {
                return _products;
            }
            set
            {
                _products = value;
                this.NotifyDataSetChanged();
            }
        }

        public event ProductListAdapterItemClickEventHandler ItemClick;

        public ProductListAdapter(List<Product> products)
        {
            Products = products;
        }

        public override int ItemCount
        {
            get
            {
                return Products != null ? Products.Count() : 0;
            }
        }

        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
        {
            var viewHolder = holder as ProductViewHolder;

            var product = Products[position];

            if (position % 2 == 0)
            {
                viewHolder.View.SetBackgroundResource(Resource.Color.rowEven);
            }
            else
            {
                viewHolder.View.SetBackgroundResource(Resource.Color.rowOdd);
            }

            viewHolder.ItemNumber.Text = product.ItemNumber;
            viewHolder.Description.Text = product.ItemDescription;
            viewHolder.Price.Text = product.Price.ToString("C");
            viewHolder.QtyOnHand.Text = product.QtyOnHand.ToString("N0");
            viewHolder.QtyAvailable.Text = product.QtyAvailable.ToString("N0");
        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            var view = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.ProductListItem, parent, false);

            var itemNumber = view.FindViewById<TextView>(Resource.Id.ItemNumber);
            var description = view.FindViewById<TextView>(Resource.Id.Description);
            var price = view.FindViewById<TextView>(Resource.Id.Price);
            var qtyOnHand = view.FindViewById<TextView>(Resource.Id.QtyOnHand);
            var qtyAvailable = view.FindViewById<TextView>(Resource.Id.QtyAvailable);

            var holder = new ProductViewHolder(view) { ItemNumber = itemNumber, Description = description, Price = price, QtyOnHand = qtyOnHand, QtyAvailable = qtyAvailable};

            holder.Click += Item_Click;

            return holder;
        }

        private void Item_Click(int position)
        {
            if (ItemClick != null)
            {
                ItemClick(Products.ElementAt(position));
            }
        }
    }
}