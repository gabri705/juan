using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.Widget;
using Barcoding.Jdl.Android.Models;

namespace Barcoding.Jdl.Android.Adapters
{
    public class OrderHeaderListAdapter : RecyclerView.Adapter
    {
        public delegate void CustomClickEventHandler(int position);
        public delegate void OrderHeaderListAdapterItemClickEventHandler(OrderHeader order);

        public class OrderHeaderViewHolder : RecyclerView.ViewHolder
        {
            public event CustomClickEventHandler Click;

            public View View { get; set; }
            public TextView CreatedDate { get; set; }
            public TextView ModifiedDate { get; set; }
            public TextView OrderNumber { get; set; }
            public TextView TotalCost { get; set; }
            public TextView PONumber { get; set; }


            public OrderHeaderViewHolder(View view)
                : base(view)
            {
                View = view;

                View.Click += View_Click;
            }

            private void View_Click(object sender, EventArgs e)
            {
                var view = sender as View;

                if (Click != null)
                {
                    Click(this.LayoutPosition);
                }
            }
        }

        private List<OrderHeader> _orders;

        public event OrderHeaderListAdapterItemClickEventHandler ItemClick;

        public OrderHeaderListAdapter(List<OrderHeader> orders)
        {
            _orders = orders;
        }

        public override int ItemCount
        {
            get
            {
                return _orders != null ? _orders.Count() : 0;
            }
        }

        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
        {
            var viewHolder = holder as OrderHeaderViewHolder;

            var order = _orders[position];

            if (position % 2 == 0)
            {
                viewHolder.View.SetBackgroundResource(Resource.Color.rowEven);
            }
            else
            {
                viewHolder.View.SetBackgroundResource(Resource.Color.rowOdd);
            }

            viewHolder.CreatedDate.Text = order.CreatedDate.ToShortDateString();
            viewHolder.ModifiedDate.Text = order.ModifiedDate.ToShortDateString();
            viewHolder.OrderNumber.Text = order.OrderNumber;
            viewHolder.TotalCost.Text = order.TotalCost.ToString("C");
            viewHolder.PONumber.Text = order.PONumber.Trim();
        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            var view = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.OrderHeaderListItem, parent, false);

            var createdDate = view.FindViewById<TextView>(Resource.Id.CreatedDate);
            var modifiedDate = view.FindViewById<TextView>(Resource.Id.ModifiedDate);
            var orderNumber = view.FindViewById<TextView>(Resource.Id.OrderNumber);
            var totalCost = view.FindViewById<TextView>(Resource.Id.TotalCost);
            var poNumber = view.FindViewById<TextView>(Resource.Id.PONumber);

            var holder = new OrderHeaderViewHolder(view)
            {
                CreatedDate = createdDate,
                ModifiedDate = modifiedDate,
                OrderNumber = orderNumber,
                TotalCost = totalCost,
                PONumber = poNumber
            };

            holder.Click += Item_Click;

            return holder;
        }

        private void Item_Click(int position)
        {
            if (ItemClick != null)
            {
                ItemClick(_orders.ElementAt(position));
            }
        }
    }
}