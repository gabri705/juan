using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.Widget;
using Barcoding.Jdl.Android.Models;

namespace Barcoding.Jdl.Android.Adapters
{
    public class LineItemListAdapter : RecyclerView.Adapter
    {
        public delegate void CustomClickEventHandler(int position);
        public delegate void LineItemListAdapterItemClickEventHandler(LineItem lineItem);

        public class LineItemViewHolder : RecyclerView.ViewHolder
        {
            public event CustomClickEventHandler Click;

            public View View { get; set; }
            public TextView ItemNumber { get; set; }
            public TextView ItemName { get; set; }
            public TextView Quantity { get; set; }

            public LineItemViewHolder(View view)
                : base(view)
            {
                View = view;

                View.Click += View_Click;
            }

            private void View_Click(object sender, EventArgs e)
            {
                var view = sender as View;

                if (Click != null)
                {
                    Click(this.LayoutPosition);
                }
            }
        }

        private List<LineItem> _lineItems;
        
        public List<LineItem> LineItems
        {
            get
            {
                return _lineItems;
            }
            set
            {
                _lineItems = value;
                this.NotifyDataSetChanged();
            }
        }

        public event LineItemListAdapterItemClickEventHandler ItemClick;

        public LineItemListAdapter(List<LineItem> lineItems)
        {
            LineItems = lineItems;
        }

        public override int ItemCount
        {
            get
            {
                return LineItems != null ? LineItems.Count() : 0;
            }
        }

        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
        {
            var viewHolder = holder as LineItemViewHolder;

            var lineItem = LineItems[position];

            if (position % 2 == 0)
            {
                viewHolder.View.SetBackgroundResource(Resource.Color.rowEven);
            }
            else
            {
                viewHolder.View.SetBackgroundResource(Resource.Color.rowOdd);
            }

            viewHolder.ItemName.Text = lineItem.ItemDescription;
            viewHolder.ItemNumber.Text = lineItem.ItemNumber;
            viewHolder.Quantity.Text = lineItem.QtyOrdered.ToString("N0");
        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            var view = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.LineItemListItem, parent, false);

            var itemNumber = view.FindViewById<TextView>(Resource.Id.ItemNumber);
            var itemName = view.FindViewById<TextView>(Resource.Id.ItemName);
            var quantity = view.FindViewById<TextView>(Resource.Id.Quantity);

            var holder = new LineItemViewHolder(view) { ItemName = itemName, ItemNumber = itemNumber, Quantity = quantity };

            holder.Click += Item_Click;

            return holder;
        }

        private void Item_Click(int position)
        {
            if (ItemClick != null)
            {
                ItemClick(LineItems.ElementAt(position));
            }
        }
    }
}