using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.Support.V7.Widget;
using Barcoding.Jdl.Android.Models;

namespace Barcoding.Jdl.Android.Adapters
{
    public class CustomerListAdapter : RecyclerView.Adapter
    {
        public delegate void CustomClickEventHandler(int position);
        public delegate void CustomerListAdapterItemClickEventHandler(Customer customer);

        public class CustomerViewHolder : RecyclerView.ViewHolder
        {
            public event CustomClickEventHandler Click;

            public View View { get; set; }
            public TextView AddressLine1 { get; set; }
            public TextView AddressLine2 { get; set; }
            public TextView City { get; set; }
            public TextView CustomerNumber { get; set; }
            public TextView CustomerName { get; set; }
            public TextView PhoneNumber { get; set; }
            public TextView PostalCode { get; set; }
            public TextView StateCode { get; set; }

            public CustomerViewHolder(View view)
                : base(view)
            {
                View = view;

                View.Click += View_Click;
            }

            private void View_Click(object sender, EventArgs e)
            {
                var view = sender as View;

                if (Click != null)
                {
                    Click(this.LayoutPosition);
                }
            }
        }

        private List<Customer> _customers;
        public List<Customer> Customers
        {
            get
            {
                return _customers;
            }
            set
            {
                _customers = value;
                this.NotifyDataSetChanged();
            }
        }

        public event CustomerListAdapterItemClickEventHandler ItemClick;

        public CustomerListAdapter(List<Customer> customers)
        {
            Customers = customers;
        }

        public override int ItemCount
        {
            get
            {
                return Customers != null ? Customers.Count() : 0;
            }
        }

        public override void OnBindViewHolder(RecyclerView.ViewHolder holder, int position)
        {
            var viewHolder = holder as CustomerViewHolder;

            var customer = Customers[position];

            if (position % 2 == 0)
            {
                viewHolder.View.SetBackgroundResource(Resource.Color.rowEven);
            }
            else
            {
                viewHolder.View.SetBackgroundResource(Resource.Color.rowOdd);
            }

            viewHolder.AddressLine1.Text = customer.AddressLine1.Trim();
            viewHolder.AddressLine2.Text = customer.AddressLine2.Trim();
            viewHolder.City.Text = customer.City.Trim();
            viewHolder.CustomerNumber.Text = customer.CustomerNumber.Trim();
            viewHolder.CustomerName.Text = customer.Name.Trim();
            viewHolder.PhoneNumber.Text = customer.PhoneNumber.Trim();
            viewHolder.PostalCode.Text = customer.PostalCode.Trim().Length > 5 ? customer.PostalCode.Trim().Substring(0, 5) : customer.PostalCode.Trim();
            viewHolder.StateCode.Text = customer.StateCode.Trim();

            if (String.IsNullOrWhiteSpace(customer.AddressLine2))
            {
                viewHolder.AddressLine2.Visibility = ViewStates.Gone;
            }
            else
            {
                viewHolder.AddressLine2.Visibility = ViewStates.Visible;
            }
        }

        public override RecyclerView.ViewHolder OnCreateViewHolder(ViewGroup parent, int viewType)
        {
            var view = LayoutInflater.From(parent.Context).Inflate(Resource.Layout.CustomerListItem, parent, false);

            var addressLine1 = view.FindViewById<TextView>(Resource.Id.AddressLine1);
            var addressLine2 = view.FindViewById<TextView>(Resource.Id.AddressLine2);
            var city = view.FindViewById<TextView>(Resource.Id.City);
            var customerNumber = view.FindViewById<TextView>(Resource.Id.CustomerNumber);
            var customerName = view.FindViewById<TextView>(Resource.Id.CustomerName);
            var phoneNumber = view.FindViewById<TextView>(Resource.Id.PhoneNumber);
            var postalCode = view.FindViewById<TextView>(Resource.Id.PostalCode);
            var stateCode = view.FindViewById<TextView>(Resource.Id.StateCode);

            var holder = new CustomerViewHolder(view)
            {
                AddressLine1 = addressLine1,
                AddressLine2 = addressLine2,
                City = city,
                CustomerNumber = customerNumber,
                CustomerName = customerName,
                PhoneNumber = phoneNumber,
                PostalCode = postalCode,
                StateCode = stateCode
            };

            holder.Click += Item_Click;

            return holder;
        }

        private void Item_Click(int position)
        {
            if (ItemClick != null)
            {
                ItemClick(Customers.ElementAt(position));
            }
        }
    }
}