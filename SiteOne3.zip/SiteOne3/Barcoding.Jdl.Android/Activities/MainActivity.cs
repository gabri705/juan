﻿using System;
using Android.App;
using Android.Content;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Android.OS;
using Android.Support.V7.App;
using Barcoding.Jdl.Android.Fragments;
using Barcoding.Jdl.Android.Helpers;
using Android.Util;

namespace Barcoding.Jdl.Android.Activities
{
    [Activity(MainLauncher = true, Icon = "@drawable/ic_launcher", ScreenOrientation = global::Android.Content.PM.ScreenOrientation.Portrait)]
    public class MainActivity : AppCompatActivity
    {
        private TextView FragmentTitleView = null;

        private string _fragmentTitle = "";

        public string FragmentTitle
        {
            get
            {
                return _fragmentTitle;
            }
            set
            {
                _fragmentTitle = value.ToUpper();

                if (FragmentTitleView != null)
                {
                    FragmentTitleView.Text = _fragmentTitle;
                }
            }
        }

        protected override void OnResume()
        {
            var filter = new IntentFilter();
            filter.AddAction("jdl.android.client.SCAN"); // TODO: get rid of this hard coded string

            RegisterReceiver(receiver, filter);

            base.OnResume();
        }

        protected override void OnPause()
        {
            UnregisterReceiver(receiver);
            base.OnPause();
        }

        private class ScanReceiver : BroadcastReceiver
        {
            private MainActivity parent;

            public ScanReceiver(MainActivity activity)
            {
                parent = activity;
            }

            public override void OnReceive(Context context, Intent intent)
            {
                if (intent.Action == "jdl.android.client.SCAN") // TODO: get rid of this hard coded string
                {
                    string source = intent.GetStringExtra("com.motorolasolutions.emdk.datawedge.source") ?? "scanner";

                    string data = intent.GetStringExtra("com.motorolasolutions.emdk.datawedge.data_string");

                    // check if data came from scanner, could come from MSR or other and that there is data
                    if (source == "scanner" && !string.IsNullOrEmpty(data))
                    {
                        string symbology = intent.GetStringExtra("com.motorolasolutions.emdk.datawedge.label_type");

                        if (!string.IsNullOrEmpty(symbology))
                        {
                            // format of the label type string is LABEL-TYPE-SYMBOLOGY
                            // so let's skip the LABEL-TYPE- portion to get just the symbology
                            symbology = symbology.Substring(11);
                        }
                        else
                        {
                            symbology = "Unknown";
                        }

                        parent.OnDataScanned(data, symbology);
                    }
                }
            }
        }

        private ScanReceiver receiver;

        protected void OnDataScanned(string data, string symbology)
        {
            var fragment = SupportFragmentManager.FindFragmentById(Resource.Id.contentFrame) as IHandlesScanEvents;

            if (fragment != null)
            {
                fragment.OnDataScanned(data, symbology);
            }
        }

        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            SetContentView(Resource.Layout.MainActivity);

            FragmentTitleView = this.FindViewById<TextView>(Resource.Id.FragmentTitle);

            SupportActionBar.SetLogo(Resource.Drawable.siteone_mobile_logo);
            SupportActionBar.SetDisplayUseLogoEnabled(true);
            SupportActionBar.SetDisplayShowHomeEnabled(true);
            SupportActionBar.Title = "";

            // set up the scanner
            InitializeScanner();

            SupportFragmentManager.BeginTransaction()
                .Replace(Resource.Id.contentFrame, new LoginFragment())
                .Commit();
        }

        protected void InitializeScanner()
        {
            receiver = new ScanReceiver(this);

            Intent i = new Intent();

            i.SetAction("com.motorolasolutions.emdk.datawedge.api.ACTION_SWITCHTOPROFILE");
            i.PutExtra("com.motorolasolutions.emdk.datawedge.api.EXTRA_PROFILENAME", "XPO");

            SendBroadcast(i);
        }

        public override void OnBackPressed()
        {
            var fragment = SupportFragmentManager.FindFragmentById(Resource.Id.contentFrame) as IHandlesBackButtonPress;

            if (fragment != null)
            {
                fragment.OnBackButtonPressed();
            }
            else
            {
                if (SupportFragmentManager.BackStackEntryCount > 0)
                {
                    SupportFragmentManager.PopBackStack();
                }
            }
        }
    }
}

