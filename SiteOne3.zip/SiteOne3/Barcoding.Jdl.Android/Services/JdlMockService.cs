using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Barcoding.Jdl.Android.Models;
using Barcoding.Jdl.Android.Helpers;

namespace Barcoding.Jdl.Android.Services
{
    public class JdlMockService : IJdlService
    {
        public async Task<List<Customer>> FindCustomers(string customerName, CustomerSearchCriteria criteria, int supplyChainNodeId = 0)
        {
            var customers = new List<Customer>();

            customers.Add(new Customer() { Name = "Customer 1", CustomerNumber = "001" });
            customers.Add(new Customer() { Name = "Customer 2", CustomerNumber = "002" });
            customers.Add(new Customer() { Name = "Customer 3", CustomerNumber = "003" });
            customers.Add(new Customer() { Name = "Customer 4", CustomerNumber = "004" });
            customers.Add(new Customer() { Name = "Customer 5", CustomerNumber = "005" });

            return customers;
        }

        public async Task<List<Product>> FindProducts(string searchString, ProductSearchCriteria criteria, int supplyChainNodeId, Guid custTreeNodeId)
        {
            var products = new List<Product>();

            products.Add(new Product() { ItemDescription = "Product 1", ItemNumber = "001", Price = 1 });
            products.Add(new Product() { ItemDescription = "Product 2", ItemNumber = "002", Price = 2 });
            products.Add(new Product() { ItemDescription = "Product 3", ItemNumber = "003", Price = 3 });
            products.Add(new Product() { ItemDescription = "Product 4", ItemNumber = "004", Price = 4 });
            products.Add(new Product() { ItemDescription = "Product 5", ItemNumber = "005", Price = 5 });

            return products;
        }

        public async Task<List<Branch>> GetBranches()
        {
            var branches = new List<Branch>();

            branches.Add(new Branch() { BranchName = "Branch 1", BranchNumber = "001" });
            branches.Add(new Branch() { BranchName = "Branch 2", BranchNumber = "002" });
            branches.Add(new Branch() { BranchName = "Branch 3", BranchNumber = "003" });
            branches.Add(new Branch() { BranchName = "Branch 4", BranchNumber = "004" });
            branches.Add(new Branch() { BranchName = "Branch 5", BranchNumber = "005" });

            return branches;
        }

        public async Task<Customer> GetCustomer(int customerNumber)
        {
            return new Customer();
        }

        public async Task<List<OrderHeader>> GetOpenOrdersForCustomer(string customerNumber, string branchNumber)
        {
            return new List<OrderHeader>();
        }

        public async Task<OrderDetails> GetOrderDetails(string orderNumber, Guid orderId)
        {
            return new OrderDetails();
        }

        public async Task<Product> GetProduct(string itemNumber, int supplyChainNodeId, Guid custTreeNodeId)
        {
            return new Product();
        }

        public async Task<SubmitOrderResponse> SubmitOrder(Branch branch, Customer customer, OrderDetails orderDetails, string poNumber = "")
        {
            return new SubmitOrderResponse() { Result = true };
        }

        public async Task<SubmitOrderResponse> UpdateOrder(UpdateOrderObject existingOrderObject, Branch branch, Customer customer, OrderDetails orderDetails)
        {
            throw new NotImplementedException();
        }

        public async Task<UpdateOrderObject> GetExistingOrderObject(Guid orderId)
        {
            throw new NotImplementedException();
        }
    }
}