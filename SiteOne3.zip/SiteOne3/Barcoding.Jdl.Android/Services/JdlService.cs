using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Barcoding.Jdl.Android.Models;
using System.Threading.Tasks;
using System.Net.Http;
using System.IO;
using Newtonsoft.Json;
using Barcoding.Jdl.Android.Helpers;

namespace Barcoding.Jdl.Android.Services
{
    public class JdlService : IJdlService
    {
        public static string BaseUrl { private get; set; }
        public static string Username { private get; set; }
        public static string Password { private get; set; }

        public void HandleErrors(HttpResponseMessage response)
        {
            if (response.IsSuccessStatusCode)
            {
                return;
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.Unauthorized)
            {
                throw new Exception("Invalid username or password.");
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.InternalServerError)
            {
                throw new Exception("The SiteOne web service encountered an error.");
            }
            else if (response.StatusCode == System.Net.HttpStatusCode.BadGateway
                || response.StatusCode == System.Net.HttpStatusCode.BadRequest
                || response.StatusCode == System.Net.HttpStatusCode.GatewayTimeout
                || response.StatusCode == System.Net.HttpStatusCode.NotFound
                || response.StatusCode == System.Net.HttpStatusCode.RequestTimeout)
            {
                throw new Exception("Could not reach the SiteOne web service.");
            }
            else
            {
                throw new Exception("An unexpected error occurred while communicating with the SiteOne web service.");
            }
        }

        public async Task<List<Branch>> GetBranches()
        {
            var result = new List<Branch>();

            var encoded = Convert.ToBase64String(Encoding.ASCII.GetBytes(String.Format("{0}:{1}", Username, Password)));

            using (var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) })
            {
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);

                using (var response = await client.GetAsync("Branches/GetActiveBranchesByNumber?branchnumber="))
                using (var data = await response.Content.ReadAsStreamAsync())
                using (var stream = new StreamReader(data))
                using (var reader = new JsonTextReader(stream))
                {
                    var serializer = new JsonSerializer() { MissingMemberHandling = MissingMemberHandling.Ignore };

                    HandleErrors(response);

                    result = serializer.Deserialize<List<Branch>>(reader);
                }
            }

            return result.OrderBy(x => x.BranchName).ThenBy(x => x.BranchNumber).ToList();
        }

        public async Task<List<Customer>> FindCustomers(string searchString, CustomerSearchCriteria criteria, int supplyChainNodeId = 0)
        {
            var result = new List<Customer>();

            var customerName = "";
            var customerNumber = "";
            var streetAddress = "";
            var city = "";
            var state = "";
            var phoneNumber = "";

            switch (criteria)
            {
                case CustomerSearchCriteria.CustomerName:
                    customerName = searchString;
                    break;
                case CustomerSearchCriteria.CustomerNumber:
                    customerNumber = searchString;
                    break;
                case CustomerSearchCriteria.StreetAddress:
                    streetAddress = searchString;
                    break;
                case CustomerSearchCriteria.City:
                    city = searchString;
                    break;
                case CustomerSearchCriteria.State:
                    state = searchString;
                    break;
                case CustomerSearchCriteria.PhoneNumber:
                    phoneNumber = searchString;
                    break;
            }

            var encoded = Convert.ToBase64String(Encoding.ASCII.GetBytes(String.Format("{0}:{1}", Username, Password)));

            using (var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) })
            {
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);

                var url = String.Format("CustomerInfo/GetCustomerDetails?CustomerNumber={0}&FirstName={1}&Street={2}&City={3}&State={4}&SupplyChainNodeId={5}&DivisionId={6}&PhoneNumber={7}", customerNumber, customerName, streetAddress, city, state, supplyChainNodeId, 1, phoneNumber);

                using (var response = await client.GetAsync(url))
                using (var data = await response.Content.ReadAsStreamAsync())
                using (var stream = new StreamReader(data))
                using (var reader = new JsonTextReader(stream))
                {
                    var serializer = new JsonSerializer() { MissingMemberHandling = MissingMemberHandling.Ignore };

                    HandleErrors(response);

                    result = serializer.Deserialize<List<Customer>>(reader);
                }
            }

            return result.OrderBy(x => x.Name).ThenBy(x => x.CustomerNumber).ToList();
        }

        public async Task<Customer> GetCustomer(int customerNumber)
        {
            var result = default(Customer);

            var encoded = Convert.ToBase64String(Encoding.ASCII.GetBytes(String.Format("{0}:{1}", Username, Password)));

            using (var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) })
            {
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);

                var url = String.Format("CustomerInfo/GetJDLCustomer/{0}", customerNumber);

                using (var response = await client.GetAsync(url))
                using (var data = await response.Content.ReadAsStreamAsync())
                using (var stream = new StreamReader(data))
                using (var reader = new JsonTextReader(stream))
                {
                    var serializer = new JsonSerializer() { MissingMemberHandling = MissingMemberHandling.Ignore };

                    HandleErrors(response);

                    result = serializer.Deserialize<Customer>(reader);
                }
            }

            return result;
        }

        public async Task<Product> GetProduct(string itemNumber, int supplyChainNodeId, Guid custTreeNodeId)
        {
            if (string.IsNullOrWhiteSpace(itemNumber))
            {
                throw new ApplicationException("You must provide a valid item number.");
            }

            var products = await FindProducts(itemNumber, ProductSearchCriteria.ItemNumber, supplyChainNodeId, custTreeNodeId);

            if (products.Count <= 0)
            {
                throw new ApplicationException("There was no product found with the specified item number.");
            }
            else if (products.Count > 1)
            {
                throw new ApplicationException("There was more than one product found with the specified item number.");
            }

            return products.First();
        }

        public async Task<List<OrderHeader>> GetOpenOrdersForCustomer(string customerNumber, string branchNumber)
        {
            var result = new List<OrderHeader>();

            if (string.IsNullOrWhiteSpace(customerNumber) || string.IsNullOrWhiteSpace(branchNumber))
            {
                return result;
            }

            var encoded = Convert.ToBase64String(Encoding.ASCII.GetBytes(String.Format("{0}:{1}", Username, Password)));

            using (var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) })
            {
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);

                var url = String.Format("Order/SearchOpenOrders?CustomerNumber={0}&startDate={1}&endDate={2}&branchNumber={3}", customerNumber, "", "", branchNumber);

                using (var response = await client.GetAsync(url))
                using (var data = await response.Content.ReadAsStreamAsync())
                using (var stream = new StreamReader(data))
                using (var reader = new JsonTextReader(stream))
                {
                    var serializer = new JsonSerializer() { MissingMemberHandling = MissingMemberHandling.Ignore };

                    HandleErrors(response);

                    result = serializer.Deserialize<List<OrderHeader>>(reader);
                }
            }

            return result.OrderByDescending(x => x.ModifiedDate).ToList();
        }

        public async Task<OrderDetails> GetOrderDetails(string orderNumber, Guid orderId)
        {
            var result = default(OrderDetails);

            if (string.IsNullOrWhiteSpace(orderNumber) || orderId == null)
            {
                return null;
            }

            var encoded = Convert.ToBase64String(Encoding.ASCII.GetBytes(String.Format("{0}:{1}", Username, Password)));

            using (var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) })
            {
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);

                var url = String.Format("Order/GetOrderDetails?orderNumber={0}&orderId={1}", orderNumber, orderId);

                using (var response = await client.GetAsync(url))
                using (var data = await response.Content.ReadAsStreamAsync())
                using (var stream = new StreamReader(data))
                using (var reader = new JsonTextReader(stream))
                {
                    var serializer = new JsonSerializer() { MissingMemberHandling = MissingMemberHandling.Ignore };

                    HandleErrors(response);

                    result = serializer.Deserialize<OrderDetails>(reader);
                }
            }

            return result;
        }

        public async Task<List<Product>> FindProducts(string searchString, ProductSearchCriteria criteria, int supplyChainNodeId, Guid custTreeNodeId)
        {
            var result = new List<Product>();

            var itemNumber = "";
            var description = "";

            switch (criteria)
            {
                case ProductSearchCriteria.ItemNumber:
                    itemNumber = searchString;
                    break;
                case ProductSearchCriteria.Description:
                    description = searchString;
                    break;
            }

            var encoded = Convert.ToBase64String(Encoding.ASCII.GetBytes(String.Format("{0}:{1}", Username, Password)));

            using (var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) })
            {
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);

                var url = String.Format("Search/GetProductDetails?ItemNumber={0}&ItemDescription={1}&supplyChainNodeId={2}&divisionId={3}&custTreeNodeId={4}", itemNumber, description, supplyChainNodeId, 1, custTreeNodeId);

                using (var response = await client.GetAsync(url))
                using (var data = await response.Content.ReadAsStreamAsync())
                using (var stream = new StreamReader(data))
                using (var reader = new JsonTextReader(stream))
                {
                    var serializer = new JsonSerializer() { MissingMemberHandling = MissingMemberHandling.Ignore };

                    HandleErrors(response);

                    result = serializer.Deserialize<List<Product>>(reader);
                }
            }

            return result;
        }

        public async Task<SubmitOrderResponse> SubmitOrder(Branch branch, Customer customer, OrderDetails orderDetails, string poNumber = "")
        {
            var result = new SubmitOrderResponse();

            var encoded = Convert.ToBase64String(Encoding.ASCII.GetBytes(String.Format("{0}:{1}", Username, Password)));

            using (var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) })
            {
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);

                var url = String.Format("Order/SubmitOrderByCustomer");

                var obj = BuildSubmitOrderObject(branch, customer, orderDetails, poNumber);

                var contentString = JsonConvert.SerializeObject(obj);

                using (var content = new StringContent(contentString, Encoding.UTF8, "application/json"))
                using (var response = await client.PostAsync(url, content))
                using (var data = await response.Content.ReadAsStreamAsync())
                using (var stream = new StreamReader(data))
                using (var reader = new JsonTextReader(stream))
                {
                    var serializer = new JsonSerializer() { MissingMemberHandling = MissingMemberHandling.Ignore };

                    HandleErrors(response);

                    result = serializer.Deserialize<SubmitOrderResponse>(reader);
                }
            }

            return result;
        }

        private object BuildSubmitOrderObject(Branch branch, Customer customer, OrderDetails orderDetails, string poNumber = "")
        {
            // merge together multiple line items for a given product
            var mergedLineItems = MergeLineItems(orderDetails.LineItems);

            orderDetails.LineItems = mergedLineItems;

            var total = 0;
            var totalQuantity = 0;

            return new
            {
                Vertex = new
                {
                    TaxTotal = 0,
                    Total = 0,
                    TaxableAmount = 0,
                    NonTaxableAmount = 0,
                    Freight = 0,
                    OrderDate = (string)null,
                    OrderNumber = (string)null
                },
                CustomerNumber = customer.CustomerNumber,
                CustTreeNodeID = customer.CustTreeNodeId,
                BillingNodeID = customer.CustTreeNodeId,
                ShippingNodeID = new Guid(),
                OrderingNodeID = new Guid(),
                SupplyChainNodeID = branch.SupplyChainNodeId,
                DeliveryOptions = new
                {
                    Delivery = false,
                    Pickup = true
                },
                HomeBranch = (string)null,
                BillingAccount = new
                {
                    CustTreeNodeID = customer.CustTreeNodeId,
                    CustomerNumber = customer.CustomerNumber,
                    DisplayName = (string)null,
                    Email = (string)null,
                    Phone = (string)null,
                    AddressInfo = new
                    {
                        CustTreeNodeID = customer.CustTreeNodeId,
                        CustomerNumber = customer.CustomerNumber,
                        DisplayName = customer.Name,
                        AddressID = customer.AddressID,
                        Street = customer.AddressLine1,
                        Street2 = customer.AddressLine2,
                        City = customer.City,
                        State = customer.StateCode,
                        Zipcode = customer.PostalCode,
                        GeoCode = (string)null,
                        AddressCode = (string)null
                    }
                },
                OrderingAccount = new
                {
                    CustTreeNodeID = new Guid(),
                    CustomerNumber = (string)null,
                    DisplayName = (string)null,
                    Email = (string)null,
                    Phone = (string)null,
                    AddressInfo = new
                    {
                        CustTreeNodeID = new Guid(),
                        CustomerNumber = (string)null,
                        DisplayName = (string)null,
                        AddressID = new Guid(),
                        Street = (string)null,
                        Street2 = (string)null,
                        City = (string)null,
                        State = (string)null,
                        Zipcode = (string)null,
                        GeoCode = (string)null,
                        AddressCode = (string)null
                    }
                },
                Total = total,
                TotalQuantity = totalQuantity,
                Products = orderDetails.LineItems.Select(x => new
                {
                    ItemNumber = x.ItemNumber,
                    SkuID = x.SkuID,
                    Name = x.ItemNumber,
                    Description = x.ItemDescription,
                    UnitPrice = x.UnitPrice,
                    TotalPrice = x.QtyOrdered * x.UnitPrice,
                    CostForGMPercent = 0,
                    ReplacementCost = x.ReplacementCost,
                    UOM = "EA",
                    Weight = 0,
                    Quantity = x.QtyOrdered
                }),
                ShipTos = new string[] { },
                SelectedShipTo = new
                {
                    CustTreeNodeID = customer.CustTreeNodeId,
                    CustomerNumber = customer.CustomerNumber,
                    DisplayName = customer.Name,
                    ShipToAddresses = new string[] { },
                    AddressID = customer.AddressID,
                    Street = customer.AddressLine1,
                    Street2 = customer.AddressLine2,
                    City = customer.City,
                    State = customer.StateCode,
                    Zipcode = customer.PostalCode,
                    SelectedContact = new
                    {
                        CustTreeNodeID = new Guid(),
                        ContactName = (string)null,
                        IsPrimary = false,
                        Phone = (string)null
                    },
                    CustomContact = new
                    {
                        CustTreeNodeID = new Guid(),
                        ContactName = (string)null,
                        IsPrimary = false,
                        Phone = (string)null
                    },
                    Contacts = new string[] { }
                },
                DeliveryCharge = 0,
                SelectedDeliveryOption = "pickup",
                Crossroads = (string)null,
                SpecialInstructions = (string)null,
                RequestedShipmentDate = (string)null,
                Branches = new string[] { },
                SelectedPickupBranch = new
                {
                    SupplyChainNodeID = branch.SupplyChainNodeId,
                    BranchNumber = branch.BranchNumber,
                    BranchName = branch.BranchName,
                    Description = "",
                    AddressID = branch.AddressID,
                    Street = branch.Street,
                    Street2 = branch.Street2,
                    City = branch.City,
                    State = branch.StateCode,
                    Zipcode = branch.PostalCode,
                    Phone = branch.PhoneNumber,
                    Distance = 0,
                    GeoCode = (string)null,
                    AddressCode = (string)null
                },
                PaymentOptions = new
                {
                    Account = true,
                    CreditCard = false
                },
                Payment = new
                {
                    CardType = (string)null,
                    CardNumber = (string)null,
                    CardLastFour = (string)null,
                    ExpirationDate = (string)null,
                    SecurityCode = (string)null,
                    NameOnCard = (string)null,
                    Address1 = (string)null,
                    Address2 = (string)null,
                    City = (string)null,
                    State = (string)null,
                    Zipcode = (string)null,
                    PONumber = poNumber
                },
                SelectedPaymentOption = "ACCOUNT",
                OpenToBuy = 0,
                Step1IsComplete = true,
                Step2IsComplete = true,
                Step3IsComplete = true,
                Step4IsComplete = false,
                Step5IsComplete = false,
                OrderSubmitted = false,
                OrderNumber = (string)null,
                OrderDate = DateTime.Now
            };
        }

        private List<LineItem> MergeLineItems(List<LineItem> lineItems)
        {
            var result = lineItems
                .GroupBy(li => new
                {
                    li.ItemNumber,
                    li.SkuID
                })
                .Select(g => new LineItem()
                {
                    ItemDescription = g.Max(x => x.ItemDescription),
                    ItemDiscount = g.Max(x => x.ItemDiscount),
                    ItemNumber = g.Key.ItemNumber,
                    ListPrice = g.Max(x => x.ListPrice),
                    NetPrice = g.Max(x => x.NetPrice),
                    QtyAvailable = g.Max(x => x.QtyAvailable),
                    QtyOnHand = g.Max(x => x.QtyOnHand),
                    QtyOrdered = g.Sum(x => x.QtyOrdered),              // sum the quantities
                    ReplacementCost = g.Max(x => x.ReplacementCost),
                    SkuID = g.Key.SkuID,
                    UnitPrice = g.Max(x => x.UnitPrice)
                })
                .ToList();

            return result;
        }

        public async Task<SubmitOrderResponse> UpdateOrder(UpdateOrderObject existingOrderObject, Branch branch, Customer customer, OrderDetails orderDetails)
        {
            var result = new SubmitOrderResponse();

            var encoded = Convert.ToBase64String(Encoding.ASCII.GetBytes(String.Format("{0}:{1}", Username, Password)));

            using (var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) })
            {
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);

                var url = String.Format("Order/UpdateOrder");

                var obj = BuildUpdateOrderObject(existingOrderObject, branch, customer, orderDetails);

                var contentString = JsonConvert.SerializeObject(obj);

                using (var content = new StringContent(contentString, Encoding.UTF8, "application/json"))
                using (var response = await client.PostAsync(url, content))
                using (var data = await response.Content.ReadAsStreamAsync())
                using (var stream = new StreamReader(data))
                using (var reader = new JsonTextReader(stream))
                {
                    var serializer = new JsonSerializer() { MissingMemberHandling = MissingMemberHandling.Ignore };

                    HandleErrors(response);

                    result = serializer.Deserialize<SubmitOrderResponse>(reader);
                }
            }

            return result;
        }

        private UpdateOrderObject BuildUpdateOrderObject(UpdateOrderObject existingOrderObject, Branch branch, Customer customer, OrderDetails orderDetails)
        {
            // merge together multiple line items for a given product
            var mergedLineItems = MergeLineItems(orderDetails.LineItems);

            orderDetails.LineItems = mergedLineItems;

            foreach (var newLineItem in orderDetails.LineItems)
            {
                var existingLineItem = existingOrderObject.OrderDetailDtos.Where(x => x.ItemNumber == newLineItem.ItemNumber && x.SkuID == newLineItem.SkuID).FirstOrDefault();

                if (existingLineItem != null)
                {
                    // we found an existing line item that matches the new one
                    existingLineItem.Qty = newLineItem.QtyOrdered;
                    existingLineItem.QtyOrdered = newLineItem.QtyOrdered;
                }
                else
                {
                    // we did not find an existing line item that matches the new one, so we need to add a new line item
                    existingOrderObject.OrderDetailDtos.Add(new OrderDetailDto()
                    {
                        ActualUnitPrice = 0,
                        DiscountedUnitPrice = newLineItem.UnitPrice,
                        ItemCost = 0,
                        ItemNumber = newLineItem.ItemNumber,
                        Qty = newLineItem.QtyOrdered,
                        QtyAvailable = newLineItem.QtyAvailable,
                        QtyBackorder = 0,
                        QtyCancelled = 0,
                        QtyLost = 0,
                        QtyOnHand = newLineItem.QtyOnHand,
                        QtyOrdered = newLineItem.QtyOrdered,
                        QtyPicked = 0,
                        ReplacementCost = newLineItem.ReplacementCost,
                        SkuID = newLineItem.SkuID
                    });
                }
            }

            // set the quantity to 0 for any line items which exist in the existing order object but do not exist in the new object
            existingOrderObject.OrderDetailDtos.Where(x => !orderDetails.LineItems.Any(y => y.ItemNumber == x.ItemNumber && y.SkuID == x.SkuID)).ToList().ForEach(z =>
            {
                z.Qty = 0;
                z.QtyOrdered = 0;
            });

            return existingOrderObject;
        }

        public async Task<UpdateOrderObject> GetExistingOrderObject(Guid orderId)
        {
            var result = new UpdateOrderObject();

            var encoded = Convert.ToBase64String(Encoding.ASCII.GetBytes(String.Format("{0}:{1}", Username, Password)));

            using (var client = new HttpClient() { BaseAddress = new Uri(BaseUrl) })
            {
                client.DefaultRequestHeaders.Accept.Add(new System.Net.Http.Headers.MediaTypeWithQualityHeaderValue("application/json"));
                client.DefaultRequestHeaders.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue("Basic", encoded);

                var url = String.Format("Order/GetByOrderHeaderId");

                var contentString = String.Format("\"{0}\"", orderId.ToString());

                using (var content = new StringContent(contentString, Encoding.UTF8, "application/json"))
                using (var response = await client.PostAsync(url, content))
                using (var data = await response.Content.ReadAsStreamAsync())
                using (var stream = new StreamReader(data))
                using (var reader = new JsonTextReader(stream))
                {
                    var serializer = new JsonSerializer() { MissingMemberHandling = MissingMemberHandling.Ignore };

                    HandleErrors(response);

                    result = serializer.Deserialize<UpdateOrderObject>(reader);
                }
            }

            return result;
        }
    }
}