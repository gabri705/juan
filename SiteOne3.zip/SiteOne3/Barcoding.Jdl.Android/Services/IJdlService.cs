using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using System.Threading.Tasks;
using Barcoding.Jdl.Android.Models;
using Barcoding.Jdl.Android.Helpers;

namespace Barcoding.Jdl.Android.Services
{
    public interface IJdlService
    {
        Task<List<Branch>> GetBranches();

        Task<List<Customer>> FindCustomers(string customerName, CustomerSearchCriteria criteria, int supplyChainNodeId = 0);

        Task<Customer> GetCustomer(int customerNumber);

        Task<Product> GetProduct(string itemNumber, int supplyChainNodeId, Guid custTreeNodeId);

        Task<List<OrderHeader>> GetOpenOrdersForCustomer(string customerNumber, string branchNumber);

        Task<OrderDetails> GetOrderDetails(string orderNumber, Guid orderId);

        Task<List<Product>> FindProducts(string searchString, ProductSearchCriteria criteria, int supplyChainNodeId, Guid custTreeNodeId);

        Task<SubmitOrderResponse> SubmitOrder(Branch branch, Customer customer, OrderDetails orderDetails, string poNumber = "");

        Task<SubmitOrderResponse> UpdateOrder(UpdateOrderObject existingOrderObject, Branch branch, Customer customer, OrderDetails orderDetails);

        Task<UpdateOrderObject> GetExistingOrderObject(Guid orderId);
    }
}