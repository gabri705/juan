﻿using Android.Content;
using Android.OS;
using Android.Support.V4.App;
using Android.Support.V7.App;
using Android.Views;
using Android.Views.InputMethods;
using Android.Widget;
using Barcoding.Jdl.Android.Activities;
using Barcoding.Jdl.Android.Helpers;
using Barcoding.Jdl.Android.Models;
using Barcoding.Jdl.Android.Services;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Barcoding.Jdl.Android.Fragments
{
    public class LoginFragment : Fragment
    {
        private EditText Username;
        private EditText Password;
        private Button LoginButton;

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.LoginFragment, null);

            Username = view.FindViewById<EditText>(Resource.Id.Username);
            Password = view.FindViewById<EditText>(Resource.Id.Password);
            LoginButton = view.FindViewById<Button>(Resource.Id.LoginButton);

            LoginButton.Click += LoginButton_Click;
            Password.EditorAction += Password_EditorAction;

            HasOptionsMenu = true;

            return view;
        }

        private async void LoginButton_Click(object sender, EventArgs e)
        {
            await Login();
        }

        public override void OnCreateOptionsMenu(IMenu menu, MenuInflater inflater)
        {
            inflater.Inflate(Resource.Menu.LoginFragmentMenu, menu);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            if (item.ItemId == Resource.Id.Settings)
            {
                this.Activity.SupportFragmentManager.BeginTransaction()
                    .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                    .Replace(Resource.Id.contentFrame, new SettingsFragment())
                    .AddToBackStack("LoginFragment")
                    .Commit();

                return true;
            }

            return base.OnOptionsItemSelected(item);
        }

        private async void Password_EditorAction(object sender, TextView.EditorActionEventArgs e)
        {
            if ((e.ActionId == ImeAction.ImeNull && e.Event != null && e.Event.Action == KeyEventActions.Up && e.Event.KeyCode == Keycode.Enter)
                || (e.ActionId == ImeAction.Done && e.Event == null)
                || (e.ActionId == ImeAction.ImeNull && e.Event == null))
            {
                await Login();
            }
        }

        public override void OnResume()
        {
            base.OnResume();

            var activity = this.Activity as MainActivity;
            if (activity != null)
            {
                activity.FragmentTitle = "Login";
            }
        }

        private async Task Login()
        {
            using (var waitHelper = new WaitHelper(this.Activity, "Getting Branch Data"))
            {
                var domain = "";

                using (var settings = this.Activity.GetSharedPreferences("JdlSettings", FileCreationMode.Private))
                {
                    domain = settings.GetString("DefaultDomain", "jdl");
                }

                var username = domain + "\\" + Username.Text.Substring(Username.Text.IndexOf("\\") + 1).Trim();
                var password = Password.Text.Trim();

                // set the base url, username, and password on the JdlService
                JdlService.BaseUrl = Resources.GetString(Resource.String.JdlServiceBaseUrl);
                JdlService.Username = username;
                JdlService.Password = password;

                // close the on-screen keyboard
                var inputMethodManager = (InputMethodManager)this.Activity.GetSystemService(Context.InputMethodService);
                inputMethodManager.HideSoftInputFromWindow(this.View.WindowToken, HideSoftInputFlags.None);

                // call the web service to authenticate the user
                try
                {
                    var service = ServiceFactory.GetJdlService();
                    var branches = await service.GetBranches();

                    // save the user information to the shared settings
                    using (var settings = this.Activity.GetSharedPreferences("JdlSettings", FileCreationMode.Private))
                    using (var editor = settings.Edit())
                    {
                        editor.PutString("CurrentUserName", username.Replace("jdl\\",""));  // TODO: get rid of this hard-coded string
                        editor.Commit();
                    }

                    using (var settings = this.Activity.GetSharedPreferences("JdlSettings", FileCreationMode.Private))
                    {
                        // check if a home branch is already configured
                        var supplyChainNodeId = settings.GetInt("HomeBranchSupplyChainNodeId", 0);

                        if (supplyChainNodeId > 0)
                        {
                            var homeBranch = branches.Where(b => b.SupplyChainNodeId == supplyChainNodeId).First();

                            // if a home branch is configured go straight to the customer search screen
                            this.Activity.SupportFragmentManager.BeginTransaction()
                                .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                                .Replace(Resource.Id.contentFrame, new CustomerSelectionFragment(homeBranch))
                                .Commit();
                        }
                        else
                        {
                            // if no home branch is configured, go to the branch selection screen
                            this.Activity.SupportFragmentManager.BeginTransaction()
                                .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                                .Replace(Resource.Id.contentFrame, new BranchSelectionFragment(branches))
                                .Commit();
                        }
                    }
                }
                catch (Exception ex)
                {
                    var errorDialog = new AlertDialog.Builder(this.Activity);
                    errorDialog.SetTitle("Error");
                    errorDialog.SetMessage(ex.Message);
                    errorDialog.SetCancelable(false);
                    errorDialog.SetNeutralButton("OK", (s, a) => { });
                    errorDialog.Show();
                }
            }
        }
    }
}
