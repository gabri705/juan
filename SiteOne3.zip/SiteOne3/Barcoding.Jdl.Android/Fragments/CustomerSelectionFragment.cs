using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.Support.V4.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Support.V7.Widget;
using Barcoding.Jdl.Android.Models;
using Barcoding.Jdl.Android.Adapters;
using Widget = Android.Widget;
using Android.Views.InputMethods;
using Barcoding.Jdl.Android.Services;
using Android.Support.V7.App;
using Barcoding.Jdl.Android.Helpers;
using Barcoding.Jdl.Android.Activities;

namespace Barcoding.Jdl.Android.Fragments
{
    public class CustomerSelectionFragment : Fragment
    {
        private Branch _branch = null;

        public List<Customer> Customers { get; set; }

        private RecyclerView CustomerList;
        private Widget.EditText Filter;
        private Widget.Spinner SearchFilterChoices;
        private SwitchCompat ToggleMyArea;
        private Widget.TextView CurrentUser;
        private Widget.TextView BranchName;
        private Widget.TextView BranchNumber;

        public CustomerSelectionFragment(Branch branch)
        {
            if (Customers == null)
            {
                Customers = new List<Customer>();
            }

            _branch = branch;
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.CustomerSelectionFragment, null);

            CustomerList = view.FindViewById<RecyclerView>(Resource.Id.CustomerList);
            Filter = view.FindViewById<Widget.EditText>(Resource.Id.Search);
            SearchFilterChoices = view.FindViewById<Widget.Spinner>(Resource.Id.CustomerSearchFilterChoices);
            ToggleMyArea = view.FindViewById<SwitchCompat>(Resource.Id.ToggleMyArea);
            CurrentUser = view.FindViewById<Widget.TextView>(Resource.Id.CurrentUser);
            BranchName = view.FindViewById<Widget.TextView>(Resource.Id.BranchName);
            BranchNumber = view.FindViewById<Widget.TextView>(Resource.Id.BranchNumber);

            Widget.ArrayAdapter spinnerAdapter = Widget.ArrayAdapter.CreateFromResource(this.Activity, Resource.Array.CustomerSearchFilterChoices, Resource.Layout.SpinnerItem);
            SearchFilterChoices.Adapter = spinnerAdapter;

            var currentUser = "";

            using (var settings = this.Activity.GetSharedPreferences("JdlSettings", FileCreationMode.Private))
            {
                currentUser = settings.GetString("CurrentUserName", "");
            }

            CurrentUser.Text = currentUser;
            BranchName.Text = _branch.BranchName;
            BranchNumber.Text = _branch.BranchNumber;

            Filter.EditorAction += Filter_EditorAction;

            // use this setting to improve performance if you know that changes in content do not change the layout size of the RecyclerView
            CustomerList.HasFixedSize = true;

            // use a linear layout manager
            CustomerList.SetLayoutManager(new LinearLayoutManager(this.Activity));

            // specify an adapter
            var adapter = new CustomerListAdapter(Customers);
            adapter.ItemClick += Adapter_ItemClick;
            CustomerList.SetAdapter(adapter);

            ToggleMyArea.CheckedChange += ToggleMyArea_CheckedChange;

            HasOptionsMenu = true;

            return view;
        }

        private async void ToggleMyArea_CheckedChange(object sender, Widget.CompoundButton.CheckedChangeEventArgs e)
        {
            if (String.IsNullOrWhiteSpace(Filter.Text))
            {
                return;
            }

            await SearchForCustomers();
        }

        public override void OnCreateOptionsMenu(IMenu menu, MenuInflater inflater)
        {
            inflater.Inflate(Resource.Menu.CustomerSelectionFragmentMenu, menu);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            if (item.ItemId == Resource.Id.Logout)
            {
                var dialog = new global::Android.App.AlertDialog.Builder(this.Activity);
                dialog.SetTitle("Logout");
                dialog.SetMessage("Are you sure you want to logout?");
                dialog.SetPositiveButton("Yes", (s, args) =>
                {
                    // clear the back-stack
                    for (int i = 0; i < FragmentManager.BackStackEntryCount; i++)
                    {
                        FragmentManager.PopBackStack();
                    }

                    // go to the login screen
                    this.Activity.SupportFragmentManager.BeginTransaction()
                        .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                        .Replace(Resource.Id.contentFrame, new LoginFragment())
                        .Commit();
                });
                dialog.SetNegativeButton("No", (s, args) => { });
                dialog.SetCancelable(false);
                dialog.Show();

                return true;
            }
            else
            {
                return base.OnOptionsItemSelected(item);
            }
        }

        private async void Filter_EditorAction(object sender, Widget.TextView.EditorActionEventArgs e)
        {
            if ((e.ActionId == ImeAction.ImeNull && e.Event != null && e.Event.Action == KeyEventActions.Up && e.Event.KeyCode == Keycode.Enter)
                || (e.ActionId == ImeAction.Done && e.Event == null)
                || (e.ActionId == ImeAction.ImeNull && e.Event == null))
            {
                await SearchForCustomers();
            }
        }

        private async System.Threading.Tasks.Task SearchForCustomers()
        {
            try
            {
                using (var waitHelper = new WaitHelper(this.Activity, "Searching for Customer"))
                {
                    // close the on-screen keyboard
                    var inputMethodManager = (InputMethodManager)this.Activity.GetSystemService(Context.InputMethodService);
                    inputMethodManager.HideSoftInputFromWindow(this.View.WindowToken, HideSoftInputFlags.None);

                    var service = ServiceFactory.GetJdlService();
                    var criteria = CustomerSearchCriteria.CustomerName;

                    switch (SearchFilterChoices.SelectedItemPosition)
                    {
                        case 0:
                            criteria = CustomerSearchCriteria.CustomerName;
                            break;
                        case 1:
                            criteria = CustomerSearchCriteria.CustomerNumber;
                            break;
                        case 2:
                            criteria = CustomerSearchCriteria.StreetAddress;
                            break;
                        case 3:
                            criteria = CustomerSearchCriteria.City;
                            break;
                        case 4:
                            criteria = CustomerSearchCriteria.State;
                            break;
                        case 5:
                            criteria = CustomerSearchCriteria.PhoneNumber;
                            break;
                        default:
                            throw new ArgumentException("Invalid search criteria selected.");
                            break;
                    }

                    Customers = await service.FindCustomers(Filter.Text, criteria, ToggleMyArea.Checked ? _branch.SupplyChainNodeId : 0);

                    if (Customers.Count == 0)
                    {
                        Widget.Toast.MakeText(this.Activity, "No matching customers found.", Widget.ToastLength.Long).Show();
                    }

                    var adapter = CustomerList.GetAdapter() as CustomerListAdapter;

                    if (adapter != null)
                    {
                        adapter.Customers = Customers;
                    }
                }
            }
            catch (Exception ex)
            {
                var errorDialog = new AlertDialog.Builder(this.Activity);
                errorDialog.SetTitle("Error");
                errorDialog.SetMessage(ex.Message);
                errorDialog.SetCancelable(false);
                errorDialog.SetNeutralButton("OK", (s, a) => { });
                errorDialog.Show();
            }
        }

        private async void Adapter_ItemClick(Customer customer)
        {
            try
            {
                using (var waitHelper = new WaitHelper(this.Activity, "Searching for Open Orders"))
                {
                    // search for open orders for the selected customer
                    var service = ServiceFactory.GetJdlService();
                    var orders = await service.GetOpenOrdersForCustomer(customer.CustomerNumber, _branch.BranchNumber);

                    if (orders.Count == 0)
                    {
                        Widget.Toast.MakeText(this.Activity, "No open orders found.", Widget.ToastLength.Long).Show();
                    }

                    // go to the open orders screen
                    this.Activity.SupportFragmentManager.BeginTransaction()
                        .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                        .Replace(Resource.Id.contentFrame, new OrdersFragment(_branch, customer, orders))
                        .AddToBackStack("CustomerSelectionFragment")
                        .Commit();
                }
            }
            catch (Exception ex)
            {
                var errorDialog = new AlertDialog.Builder(this.Activity);
                errorDialog.SetTitle("Error");
                errorDialog.SetMessage(ex.Message);
                errorDialog.SetCancelable(false);
                errorDialog.SetNeutralButton("OK", (s, a) => { });
                errorDialog.Show();
            }
        }

        public override void OnResume()
        {
            base.OnResume();

            var activity = this.Activity as MainActivity;
            if (activity != null)
            {
                activity.FragmentTitle = "Select a Customer";
            }
        }
    }
}