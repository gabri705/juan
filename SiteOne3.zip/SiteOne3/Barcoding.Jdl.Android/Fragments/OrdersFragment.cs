using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.Support.V4.App;

using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Barcoding.Jdl.Android.Models;
using Android.Support.V7.Widget;
using Barcoding.Jdl.Android.Adapters;
using Barcoding.Jdl.Android.Services;
using Barcoding.Jdl.Android.Helpers;
using Android.Support.Design.Widget;
using App = Android.App;
using Barcoding.Jdl.Android.Activities;

namespace Barcoding.Jdl.Android.Fragments
{
    public class OrdersFragment : Fragment
    {
        public List<OrderHeader> Orders { get; set; }
        public Customer Customer { get; set; }
        public Branch Branch { get; set; }

        private RecyclerView OrderHeaderList;
        private FloatingActionButton CreateNewOrderButton;
        private TextView CustomerName;
        private TextView CustomerNumber;

        public OrdersFragment(Branch branch, Customer customer, List<OrderHeader> orders)
        {
            Orders = orders;
            Customer = customer;
            Branch = branch;
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.OrdersFragment, null);

            OrderHeaderList = view.FindViewById<RecyclerView>(Resource.Id.OrderHeaderList);
            CreateNewOrderButton = view.FindViewById<FloatingActionButton>(Resource.Id.CreateNewOrderButton);
            CustomerName = view.FindViewById<TextView>(Resource.Id.CustomerName);
            CustomerNumber = view.FindViewById<TextView>(Resource.Id.CustomerNumber);

            CustomerName.Text = Customer.Name;
            CustomerNumber.Text = Customer.CustomerNumber;

            CreateNewOrderButton.Click += CreateNewOrderButton_Click;

            // use this setting to improve performance if you know that changes in content do not change the layout size of the RecyclerView
            OrderHeaderList.HasFixedSize = true;

            // use a linear layout manager
            OrderHeaderList.SetLayoutManager(new LinearLayoutManager(this.Activity));

            // specify an adapter
            var adapter = new OrderHeaderListAdapter(Orders);
            adapter.ItemClick += Adapter_ItemClick;
            OrderHeaderList.SetAdapter(adapter);

            HasOptionsMenu = true;

            return view;
        }

        public override void OnCreateOptionsMenu(IMenu menu, MenuInflater inflater)
        {
            inflater.Inflate(Resource.Menu.OrdersFragmentMenu, menu);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            if (item.ItemId == Resource.Id.Logout)
            {
                var dialog = new global::Android.App.AlertDialog.Builder(this.Activity);
                dialog.SetTitle("Logout");
                dialog.SetMessage("Are you sure you want to logout?");
                dialog.SetPositiveButton("Yes", (s, args) =>
                {
                    // clear the back-stack
                    for (int i = 0; i < FragmentManager.BackStackEntryCount; i++)
                    {
                        FragmentManager.PopBackStack();
                    }

                    // go to the login screen
                    this.Activity.SupportFragmentManager.BeginTransaction()
                        .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                        .Replace(Resource.Id.contentFrame, new LoginFragment())
                        .Commit();
                });
                dialog.SetNegativeButton("No", (s, args) => { });
                dialog.SetCancelable(false);
                dialog.Show();

                return true;
            }
            else
            {
                return base.OnOptionsItemSelected(item);
            }
        }

        private void CreateNewOrderButton_Click(object sender, EventArgs e)
        {
            // go to the line items screen
            this.Activity.SupportFragmentManager.BeginTransaction()
                .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                .Replace(Resource.Id.contentFrame, new LineItemsFragment(Branch, Customer, new OrderDetails(), false))
                .AddToBackStack("OrdersFragment")
                .Commit();
        }

        public override void OnResume()
        {
            base.OnResume();

            var activity = this.Activity as MainActivity;
            if (activity != null)
            {
                activity.FragmentTitle = "Open Orders";
            }
        }

        private async void Adapter_ItemClick(OrderHeader order)
        {
            try
            {
                using (var waitHelper = new WaitHelper(this.Activity, "Getting Order Details"))
                {
                    var service = ServiceFactory.GetJdlService();
                    var orderDetails = await service.GetOrderDetails(order.OrderNumber, order.OrderId);

                    // HACK: set the PO Number because it doesn't come back from GetOrderDetails but fortunately we already have it
                    orderDetails.OrderHeader.PONumber = order.PONumber;

                    // go to the line items screen
                    this.Activity.SupportFragmentManager.BeginTransaction()
                        .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                        .Replace(Resource.Id.contentFrame, new LineItemsFragment(Branch, Customer, orderDetails, true))
                        .AddToBackStack("OrdersFragment")
                        .Commit();
                }
            }
            catch (Exception ex)
            {
                var errorDialog = new App.AlertDialog.Builder(this.Activity);
                errorDialog.SetTitle("Error");
                errorDialog.SetMessage(ex.Message);
                errorDialog.SetCancelable(false);
                errorDialog.SetNeutralButton("OK", (s, a) => { });
                errorDialog.Show();
            }
        }
    }
}