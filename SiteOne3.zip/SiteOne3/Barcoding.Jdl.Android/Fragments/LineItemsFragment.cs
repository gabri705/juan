using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.Support.V4.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Android.Support.V7.Widget;
using Barcoding.Jdl.Android.Models;
using Barcoding.Jdl.Android.Adapters;
using Barcoding.Jdl.Android.Helpers;
using Barcoding.Jdl.Android.Services;
using Android.Support.V7.App;
using Android.Views.InputMethods;
using Android.Support.Design.Widget;
using System.Threading.Tasks;
using Barcoding.Jdl.Android.Activities;
using Com.Honeywell.Aidc;

namespace Barcoding.Jdl.Android.Fragments
{
    public class LineItemsFragment : Fragment, IHandlesScanEvents, IHandlesBackButtonPress
    {
        private AidcManager _aidcManager = null;
        private BarcodeReader _barcodeReader = null;

        public OrderDetails OrderDetails { get; set; }
        public Branch Branch { get; set; }
        public Customer Customer { get; set; }
        public string PoNumber { get; set; }
        public bool ExistingOrder { get; set; }

        private RecyclerView LineItemList;
        private FloatingActionButton AddOrderLineButton;
        private TextView CurrentTotal;

        public LineItemsFragment(Branch branch, Customer customer, OrderDetails orderDetails, bool existingOrder)
        {
            OrderDetails = orderDetails;
            Branch = branch;
            Customer = customer;
            PoNumber = existingOrder ? orderDetails.OrderHeader.PONumber : "";
            ExistingOrder = existingOrder;
        }

        public override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);

            // set up honeywell scanner
            AidcManager.Created += AidcManager_Created;
            AidcManager.Create(Activity);
        }

        private void AidcManager_Created(AidcManager manager)
        {
            _aidcManager = manager;
            _barcodeReader = _aidcManager.CreateBarcodeReader();
            _barcodeReader.Initialize();
            _barcodeReader.BarcodeScanned += barcodeReader_BarcodeScanned;
            _barcodeReader.SetProperty(BarcodeReader.PropertyTriggerControlMode, BarcodeReader.TriggerControlModeAutoControl);
            _barcodeReader.Claim();
        }

        private void barcodeReader_BarcodeScanned(BarcodeReadEvent e)
        {
            Activity.RunOnUiThread(() =>
            {
                OnDataScanned(e.BarcodeData, null);
            });
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.LineItemsFragment, null);

            LineItemList = view.FindViewById<RecyclerView>(Resource.Id.LineItemList);
            AddOrderLineButton = view.FindViewById<FloatingActionButton>(Resource.Id.AddOrderLineButton);
            CurrentTotal = view.FindViewById<TextView>(Resource.Id.CurrentTotal);

            AddOrderLineButton.Click += AddOrderLineButton_Click;

            // use this setting to improve performance if you know that changes in content do not change the layout size of the RecyclerView
            LineItemList.HasFixedSize = true;

            // use a linear layout manager
            LineItemList.SetLayoutManager(new LinearLayoutManager(this.Activity));

            // specify an adapter
            var adapter = new LineItemListAdapter(OrderDetails.LineItems);
            adapter.ItemClick += Adapter_ItemClick;
            LineItemList.SetAdapter(adapter);

            CurrentTotal.Text = OrderDetails.LineItems.Sum(x => (x.QtyOrdered * x.UnitPrice)).ToString("C");

            HasOptionsMenu = true;

            if (this.OrderDetails.LineItems.Count == 0)
            {
                var input = new EditText(this.Activity);
                input.SetSingleLine(true);

                // prompt the user to enter a PO number
                var builder = new global::Android.App.AlertDialog.Builder(this.Activity);
                builder.SetTitle("PO Number");
                builder.SetMessage("Enter a PO Number:");
                builder.SetView(input);
                builder.SetPositiveButton("Ok", (s, args) =>
                {
                    // this is a dummy handler, we add the actual handler after the dialog is created from the builder
                });
                builder.SetNegativeButton("Cancel", (s, args) =>
                {
                    // if the user does not enter a PO number, they cannot start a new order
                    FragmentManager.PopBackStack();
                });
                builder.SetCancelable(false);

                var dialog = builder.Create();
                dialog.Show();

                var okButton = dialog.GetButton((int)DialogInterface.ButtonPositive);
                okButton.Click += (s, e) =>
                {
                    var poNumber = input.Text;

                    if (Customer.PONumberRequired && string.IsNullOrWhiteSpace(poNumber))
                    {
                        Toast.MakeText(this.Activity, "You must enter a PO Number to continue.", ToastLength.Long).Show();
                    }
                    else
                    {
                        PoNumber = poNumber;
                        dialog.Dismiss();
                    }
                };
            }

            return view;
        }

        public override void OnCreateOptionsMenu(IMenu menu, MenuInflater inflater)
        {
            inflater.Inflate(Resource.Menu.LineItemsFragmentMenu, menu);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            if (item.ItemId == Resource.Id.SubmitOrder)
            {
                var dialog = new global::Android.App.AlertDialog.Builder(this.Activity);
                dialog.SetTitle("Submit Order");
                dialog.SetMessage("Are you sure you want to submit this order?");
                dialog.SetPositiveButton("Yes", (s, args) =>
                {
                    SubmitOrder();
                });
                dialog.SetNegativeButton("No", (s, args) => { });
                dialog.SetCancelable(false);
                dialog.Show();

                return true;
            }
            else
            {
                return base.OnOptionsItemSelected(item);
            }
        }

        private async Task SubmitOrder()
        {
            try
            {
                using (var waitHelper = new WaitHelper(this.Activity, "Submitting Order"))
                {
                    var service = ServiceFactory.GetJdlService();

                    var response = new SubmitOrderResponse();

                    if (ExistingOrder)
                    {
                        // get the existing order object
                        var existingOrderObject = await service.GetExistingOrderObject(OrderDetails.OrderHeader.OrderId);

                        // submit the order and get the response back from the web service
                        response = await service.UpdateOrder(existingOrderObject, Branch, Customer, OrderDetails);

                        // TODO: uncomment this code when SiteOne fixes the issue of UpdateOrder returning Result = false on a successful update
                        //if (response.Result == true)
                        //{
                        // get the order details from the web service
                        var submittedOrderDetails = await service.GetOrderDetails(OrderDetails.OrderHeader.OrderNumber, OrderDetails.OrderHeader.OrderId);

                        // go to the order summary screen
                        this.Activity.SupportFragmentManager.BeginTransaction()
                            .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                            .Replace(Resource.Id.contentFrame, new OrderSummaryFragment(submittedOrderDetails, Branch, Customer, PoNumber))
                            .AddToBackStack("LineItemsFragment")
                            .Commit();
                        //}
                        //else
                        //{
                        //    var errorDialog = new AlertDialog.Builder(this.Activity);
                        //    errorDialog.SetTitle("Error");
                        //    errorDialog.SetMessage("The SiteOne web service encountered an error.");
                        //    errorDialog.SetCancelable(false);
                        //    errorDialog.SetNeutralButton("OK", (sender, a) => { });
                        //    errorDialog.Show();
                        //}
                    }
                    else
                    {
                        // submit the order and get the response back from the web service
                        response = await service.SubmitOrder(Branch, Customer, OrderDetails, PoNumber);

                        // TODO: uncomment this code when SiteOne fixes the issue of UpdateOrder returning Result = false on a successful update
                        //if (response.Result == true)
                        //{
                        // get the order details from the web service
                        var submittedOrderDetails = await service.GetOrderDetails(response.OrderNumber, response.OrderId);

                        // go to the order summary screen
                        this.Activity.SupportFragmentManager.BeginTransaction()
                            .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                            .Replace(Resource.Id.contentFrame, new OrderSummaryFragment(submittedOrderDetails, Branch, Customer, PoNumber))
                            .AddToBackStack("LineItemsFragment")
                            .Commit();
                        //}
                        //else
                        //{
                        //    var errorDialog = new AlertDialog.Builder(this.Activity);
                        //    errorDialog.SetTitle("Error");
                        //    errorDialog.SetMessage("The SiteOne web service encountered an error.");
                        //    errorDialog.SetCancelable(false);
                        //    errorDialog.SetNeutralButton("OK", (sender, a) => { });
                        //    errorDialog.Show();
                        //}
                    }


                }
            }
            catch (Exception ex)
            {
                var errorDialog = new AlertDialog.Builder(this.Activity);
                errorDialog.SetTitle("Error");
                errorDialog.SetMessage(ex.Message);
                errorDialog.SetCancelable(false);
                errorDialog.SetNeutralButton("OK", (s, a) => { });
                errorDialog.Show();
            }
        }

        private void AddOrderLineButton_Click(object sender, EventArgs e)
        {
            // go to the product search screen
            this.Activity.SupportFragmentManager.BeginTransaction()
                .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                .Replace(Resource.Id.contentFrame, new ProductSearchFragment(OrderDetails, Branch, Customer))
                .AddToBackStack("LineItemsFragment")
                .Commit();
        }

        public override void OnResume()
        {
            base.OnResume();

            _barcodeReader?.Claim();

            var activity = this.Activity as MainActivity;
            if (activity != null)
            {
                activity.FragmentTitle = "Order Line Items";
            }
        }

        public override void OnPause()
        {
            base.OnPause();

            _barcodeReader?.Release();
        }

        public override void OnDestroy()
        {
            base.OnDestroy();

            _barcodeReader?.Close();
            _barcodeReader = null;

            _aidcManager?.Close();
            _aidcManager = null;
        }

        private void Adapter_ItemClick(LineItem lineItem)
        {
            // go to the line item details screen
            this.Activity.SupportFragmentManager.BeginTransaction()
                .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                .Replace(Resource.Id.contentFrame, new LineItemDetailsFragment(OrderDetails, lineItem, true))
                .AddToBackStack("LineItemsFragment")
                .Commit();
        }

        public async void OnDataScanned(string data, string symbology)
        {
            try
            {
                using (var waitHelper = new WaitHelper(this.Activity, "Getting Product Details"))
                {
                    var service = ServiceFactory.GetJdlService();
                    var product = await service.GetProduct(data, Branch.SupplyChainNodeId, Customer.CustTreeNodeId);

                    var lineItem = new LineItem()
                    {
                        ItemDescription = product.ItemDescription,
                        ItemNumber = product.ItemNumber,
                        QtyAvailable = product.QtyAvailable,
                        QtyOnHand = product.QtyOnHand,
                        QtyOrdered = 0,
                        ReplacementCost = product.ReplacementCost,
                        SkuID = product.SkuID,
                        UnitPrice = product.Price
                    };

                    // go to the line item details screen
                    this.Activity.SupportFragmentManager.BeginTransaction()
                        .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                        .Replace(Resource.Id.contentFrame, new LineItemDetailsFragment(OrderDetails, lineItem, false))
                        .AddToBackStack("LineItemsFragment")
                        .Commit();
                }
            }
            catch (Exception ex)
            {
                var errorDialog = new AlertDialog.Builder(this.Activity);
                errorDialog.SetTitle("Error");
                errorDialog.SetMessage(ex.Message);
                errorDialog.SetCancelable(false);
                errorDialog.SetNeutralButton("OK", (s, a) => { });
                errorDialog.Show();
            }
        }

        public void OnBackButtonPressed()
        {
            var dialog = new global::Android.App.AlertDialog.Builder(this.Activity);
            dialog.SetTitle("Discard Changes");
            dialog.SetMessage("Your changes to this order have not been submitted. Do you want to discard your changes?");
            dialog.SetPositiveButton("Yes", (s, args) =>
            {
                FragmentManager.PopBackStack();
            });
            dialog.SetNegativeButton("No", (s, args) => { });
            dialog.SetCancelable(false);
            dialog.Show();
        }
    }
}
