using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.Support.V4.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Barcoding.Jdl.Android.Helpers;
using Barcoding.Jdl.Android.Models;
using Barcoding.Jdl.Android.Activities;

namespace Barcoding.Jdl.Android.Fragments
{
    public class OrderSummaryFragment : Fragment, IHandlesBackButtonPress
    {
        private OrderDetails OrderDetails { get; set; }
        private Branch Branch { get; set; }
        private Customer Customer { get; set; }
        private string PoNumber { get; set; }

        private TextView OrderNumber;
        private TextView TotalCost;
        private TextView CustomerName;
        private TextView CustomerNumber;
        private TextView PoNumberField;

        public OrderSummaryFragment(OrderDetails orderDetails, Branch branch, Customer customer, string poNumber = "")
        {
            OrderDetails = orderDetails;
            Branch = branch;
            Customer = customer;
            PoNumber = poNumber;
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.OrderSummaryFragment, null);

            OrderNumber = view.FindViewById<TextView>(Resource.Id.OrderNumber);
            TotalCost = view.FindViewById<TextView>(Resource.Id.TotalCost);
            CustomerName = view.FindViewById<TextView>(Resource.Id.CustomerName);
            CustomerNumber = view.FindViewById<TextView>(Resource.Id.CustomerNumber);
            PoNumberField = view.FindViewById<TextView>(Resource.Id.PoNumber);

            OrderNumber.Text = OrderDetails.OrderHeader.OrderNumber;
            TotalCost.Text = OrderDetails.OrderHeader.TotalCost.ToString("C");
            CustomerName.Text = Customer.Name;
            CustomerNumber.Text = Customer.CustomerNumber;
            PoNumberField.Text = PoNumber;

            HasOptionsMenu = true;

            return view;
        }

        public override void OnCreateOptionsMenu(IMenu menu, MenuInflater inflater)
        {
            inflater.Inflate(Resource.Menu.OrderSummaryFragmentMenu, menu);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            if(item.ItemId == Resource.Id.Done)
            {
                // go back to the customer search screen
                FragmentManager.PopBackStack("CustomerSelectionFragment", (int)global::Android.App.PopBackStackFlags.Inclusive);

                return true;
            }
            else
            {
                return base.OnOptionsItemSelected(item);
            }
        }

        public override void OnResume()
        {
            base.OnResume();

            var activity = this.Activity as MainActivity;
            if (activity != null)
            {
                activity.FragmentTitle = "Order Summary";
            }
        }

        public void OnBackButtonPressed()
        {
            // don't allow the user to navigate backwards after submitting an order
        }
    }
}