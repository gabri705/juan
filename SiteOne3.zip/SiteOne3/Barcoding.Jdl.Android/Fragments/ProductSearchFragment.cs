using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.Support.V4.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Support.V7.Widget;
using Barcoding.Jdl.Android.Models;
using Barcoding.Jdl.Android.Adapters;
using Widget = Android.Widget;
using Android.Views.InputMethods;
using Barcoding.Jdl.Android.Services;
using Android.Support.V7.App;
using Barcoding.Jdl.Android.Helpers;
using Barcoding.Jdl.Android.Activities;

namespace Barcoding.Jdl.Android.Fragments
{
    public class ProductSearchFragment : Fragment
    {
        public List<Product> Products { get; set; }
        public OrderDetails OrderDetails { get; set; }
        public Branch Branch { get; set; }
        public Customer Customer { get; set; }

        private RecyclerView ProductList;
        private Widget.EditText Filter;
        private Widget.Spinner SearchFilterChoices;

        public ProductSearchFragment(OrderDetails orderDetails, Branch branch, Customer customer)
        {
            OrderDetails = orderDetails;
            Branch = branch;
            Customer = customer;

            Products = new List<Product>();
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.ProductSearchFragment, null);

            ProductList = view.FindViewById<RecyclerView>(Resource.Id.ProductList);
            Filter = view.FindViewById<Widget.EditText>(Resource.Id.Search);
            SearchFilterChoices = view.FindViewById<Widget.Spinner>(Resource.Id.ProductSearchFilterChoices);

            Widget.ArrayAdapter spinnerAdapter = Widget.ArrayAdapter.CreateFromResource(this.Activity, Resource.Array.ProductSearchFilterChoices, Resource.Layout.SpinnerItem);
            SearchFilterChoices.Adapter = spinnerAdapter;

            Filter.EditorAction += Filter_EditorAction;

            // use this setting to improve performance if you know that changes in content do not change the layout size of the RecyclerView
            ProductList.HasFixedSize = true;

            // use a linear layout manager
            ProductList.SetLayoutManager(new LinearLayoutManager(this.Activity));

            // specify an adapter
            var adapter = new ProductListAdapter(Products);
            adapter.ItemClick += Adapter_ItemClick;
            ProductList.SetAdapter(adapter);

            return view;
        }

        private async void Filter_EditorAction(object sender, Widget.TextView.EditorActionEventArgs e)
        {
            if ((e.ActionId == ImeAction.ImeNull && e.Event != null && e.Event.Action == KeyEventActions.Up && e.Event.KeyCode == Keycode.Enter)
                || (e.ActionId == ImeAction.Done && e.Event == null)
                || (e.ActionId == ImeAction.ImeNull && e.Event == null))
            {
                try
                {
                    using (var waitHelper = new WaitHelper(this.Activity, "Searching for Product"))
                    {
                        // close the on-screen keyboard
                        var inputMethodManager = (InputMethodManager)this.Activity.GetSystemService(Context.InputMethodService);
                        inputMethodManager.HideSoftInputFromWindow(this.View.WindowToken, HideSoftInputFlags.None);

                        var service = ServiceFactory.GetJdlService();
                        var criteria = ProductSearchCriteria.ItemNumber;

                        switch (SearchFilterChoices.SelectedItemPosition)
                        {
                            case 0:
                                criteria = ProductSearchCriteria.Description;
                                break;
                            case 1:
                                criteria = ProductSearchCriteria.ItemNumber;
                                break;
                            default:
                                throw new ArgumentException("Invalid search criteria selected.");
                                break;
                        }

                        Products = await service.FindProducts(Filter.Text, criteria, Branch.SupplyChainNodeId, Customer.CustTreeNodeId);

                        if (Products.Count == 0)
                        {
                            Widget.Toast.MakeText(this.Activity, "No matching products found.", Widget.ToastLength.Long).Show();
                        }

                        var adapter = ProductList.GetAdapter() as ProductListAdapter;

                        if (adapter != null)
                        {
                            adapter.Products = Products.OrderByDescending(p => p.QtyOnHand).ToList();
                        }
                    }
                }
                catch (Exception ex)
                {
                    var errorDialog = new AlertDialog.Builder(this.Activity);
                    errorDialog.SetTitle("Error");
                    errorDialog.SetMessage(ex.Message);
                    errorDialog.SetCancelable(false);
                    errorDialog.SetNeutralButton("OK", (s, a) => { });
                    errorDialog.Show();
                }
            }
        }

        private async void Adapter_ItemClick(Product product)
        {
            try
            {
                using (var waitHelper = new WaitHelper(this.Activity, "Getting Product Details"))
                {
                    // create a new line item for the selected product
                    var lineItem = new LineItem()
                    {
                        ItemDescription = product.ItemDescription,
                        ItemNumber = product.ItemNumber,
                        QtyAvailable = product.QtyAvailable,
                        QtyOnHand = product.QtyOnHand,
                        QtyOrdered = 0,
                        ReplacementCost = product.ReplacementCost,
                        SkuID = product.SkuID,
                        UnitPrice = product.Price
                    };

                    // go to the line item details screen
                    this.Activity.SupportFragmentManager.BeginTransaction()
                        .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                        .Replace(Resource.Id.contentFrame, new LineItemDetailsFragment(OrderDetails, lineItem, false))
                        .AddToBackStack("ProductSearchFragment")
                        .Commit();
                }
            }
            catch (Exception ex)
            {
                var errorDialog = new AlertDialog.Builder(this.Activity);
                errorDialog.SetTitle("Error");
                errorDialog.SetMessage(ex.Message);
                errorDialog.SetCancelable(false);
                errorDialog.SetNeutralButton("OK", (s, a) => { });
                errorDialog.Show();
            }
        }

        public override void OnResume()
        {
            base.OnResume();

            var activity = this.Activity as MainActivity;
            if (activity != null)
            {
                activity.FragmentTitle = "Search for Product to Add";
            }
        }
    }
}