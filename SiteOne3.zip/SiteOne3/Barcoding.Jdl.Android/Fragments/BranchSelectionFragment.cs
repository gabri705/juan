using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.Support.V4.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Barcoding.Jdl.Android.Models;
using Barcoding.Jdl.Android.Adapters;
using Android.Support.V7.Widget;
using Android.Graphics;
using Barcoding.Jdl.Android.Activities;

namespace Barcoding.Jdl.Android.Fragments
{
    public class BranchSelectionFragment : Fragment
    {
        public List<Branch> Branches { get; set; }

        private RecyclerView BranchList;
        private EditText Filter;

        public BranchSelectionFragment()
        {
            Branches = new List<Branch>();
        }

        public BranchSelectionFragment(List<Branch> branches)
        {
            Branches = branches;
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.BranchSelectionFragment, null);

            BranchList = view.FindViewById<RecyclerView>(Resource.Id.BranchList);
            Filter = view.FindViewById<EditText>(Resource.Id.Filter);

            Filter.TextChanged += Filter_TextChanged;

            // use this setting to improve performance if you know that changes in content do not change the layout size of the RecyclerView
            //BranchList.HasFixedSize = true;

            // use a linear layout manager
            BranchList.SetLayoutManager(new LinearLayoutManager(this.Activity));

            // specify an adapter
            var adapter = new BranchListAdapter(Branches);
            adapter.ItemClick += Adapter_ItemClick;
            BranchList.SetAdapter(adapter);

            HasOptionsMenu = true;

            return view;
        }

        public override void OnCreateOptionsMenu(IMenu menu, MenuInflater inflater)
        {
            inflater.Inflate(Resource.Menu.BranchSelectionFragmentMenu, menu);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            if (item.ItemId == Resource.Id.Logout)
            {
                var dialog = new global::Android.App.AlertDialog.Builder(this.Activity);
                dialog.SetTitle("Logout");
                dialog.SetMessage("Are you sure you want to logout?");
                dialog.SetPositiveButton("Yes", (s, args) =>
                {
                    // clear the back-stack
                    for (int i = 0; i < FragmentManager.BackStackEntryCount; i++)
                    {
                        FragmentManager.PopBackStack();
                    }

                    // go to the login screen
                    this.Activity.SupportFragmentManager.BeginTransaction()
                        .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                        .Replace(Resource.Id.contentFrame, new LoginFragment())
                        .Commit();
                });
                dialog.SetNegativeButton("No", (s, args) => { });
                dialog.SetCancelable(false);
                dialog.Show();

                return true;
            }
            else
            {
                return base.OnOptionsItemSelected(item);
            }
        }

        private void Filter_TextChanged(object sender, global::Android.Text.TextChangedEventArgs e)
        {
            var adapter = BranchList.GetAdapter() as BranchListAdapter;

            if (adapter != null)
            {
                adapter.FilterItems(Filter.Text);
            }
        }

        private void Adapter_ItemClick(Branch branch)
        {
            // save the selected branch as the home branch
            using (var settings = this.Activity.GetSharedPreferences("JdlSettings", FileCreationMode.Private))
            using (var editor = settings.Edit())
            {
                editor.PutInt("HomeBranchSupplyChainNodeId", branch.SupplyChainNodeId);
                editor.PutString("HomeBranchName", branch.BranchName);
                editor.PutString("HomeBranchNumber", branch.BranchNumber);
                editor.Commit();
            }

            // go to the customer selection screen
            this.Activity.SupportFragmentManager.BeginTransaction()
                .SetCustomAnimations(Resource.Animation.SlideInLeft, Resource.Animation.SlideOutLeft, Resource.Animation.SlideInRight, Resource.Animation.SlideOutRight)
                .Replace(Resource.Id.contentFrame, new CustomerSelectionFragment(branch))
                .Commit();
        }

        public override void OnResume()
        {
            base.OnResume();

            var activity = this.Activity as MainActivity;
            if (activity != null)
            {
                activity.FragmentTitle = "Select a Branch";
            }
        }
    }
}
