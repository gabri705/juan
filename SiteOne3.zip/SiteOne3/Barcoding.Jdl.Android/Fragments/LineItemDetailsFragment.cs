using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using App = Android.App;
using Android.Support.V4.App;
using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Barcoding.Jdl.Android.Models;
using Android.Views.InputMethods;
using Barcoding.Jdl.Android.Helpers;
using Barcoding.Jdl.Android.Activities;

namespace Barcoding.Jdl.Android.Fragments
{
    public class LineItemDetailsFragment : Fragment
    {
        public LineItem LineItem { get; set; }
        public OrderDetails OrderDetails { get; set; }
        public bool ExistingLineItem { get; set; }

        private TextView ItemName;
        private TextView ItemNumber;
        private EditText Quantity;
        private TextView QtyAvailable;
        private TextView QtyOnHand;
        private TextView UnitPrice;

        public LineItemDetailsFragment(OrderDetails orderDetails, LineItem lineItem, bool existingLineItem)
        {
            OrderDetails = orderDetails;
            LineItem = lineItem;
            ExistingLineItem = existingLineItem;
        }

        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.LineItemDetailsFragment, null);

            ItemName = view.FindViewById<TextView>(Resource.Id.ItemName);
            ItemNumber = view.FindViewById<TextView>(Resource.Id.ItemNumber);
            Quantity = view.FindViewById<EditText>(Resource.Id.Quantity);
            QtyAvailable = view.FindViewById<TextView>(Resource.Id.QtyAvailable);
            QtyOnHand = view.FindViewById<TextView>(Resource.Id.QtyOnHand);
            UnitPrice = view.FindViewById<TextView>(Resource.Id.UnitPrice);

            ItemName.Text = LineItem.ItemDescription;
            ItemNumber.Text = LineItem.ItemNumber;
            Quantity.Text = LineItem.QtyOrdered.ToString("N0");
            QtyAvailable.Text = LineItem.QtyAvailable.ToString("N0");
            QtyOnHand.Text = LineItem.QtyOnHand.ToString("N0");
            UnitPrice.Text = LineItem.UnitPrice.ToString("C");

            Quantity.EditorAction += Quantity_EditorAction;

            // give the quantity text field focus
            if (Quantity.RequestFocus())
            {
                // show the on-screen keyboard
                var inputMethodManager = (InputMethodManager)this.Activity.GetSystemService(Context.InputMethodService);
                inputMethodManager.ToggleSoftInput(ShowFlags.Forced, HideSoftInputFlags.ImplicitOnly);
            }

            HasOptionsMenu = true;

            return view;
        }

        public override void OnCreateOptionsMenu(IMenu menu, MenuInflater inflater)
        {
            inflater.Inflate(Resource.Menu.LineItemDetailsFragmentMenu, menu);
        }

        public override bool OnOptionsItemSelected(IMenuItem item)
        {
            if (item.ItemId == Resource.Id.Delete)
            {
                var dialog = new global::Android.App.AlertDialog.Builder(this.Activity);
                dialog.SetTitle("Delete Line Item");
                dialog.SetMessage("Are you sure you want to delete this line item?");
                dialog.SetPositiveButton("Yes", (s, args) =>
                {
                    if (ExistingLineItem)
                    {
                        // remove the line item
                        OrderDetails.LineItems.Remove(LineItem);
                    }

                    // go to the line items screen
                    FragmentManager.PopBackStack("LineItemsFragment", (int)App.PopBackStackFlags.Inclusive);
                });
                dialog.SetNegativeButton("No", (s, args) => { });
                dialog.SetCancelable(false);
                dialog.Show();

                return true;
            }
            else
            {
                return base.OnOptionsItemSelected(item);
            }
        }

        private void Quantity_EditorAction(object sender, TextView.EditorActionEventArgs e)
        {
            if ((e.ActionId == ImeAction.ImeNull && e.Event != null && e.Event.Action == KeyEventActions.Up && e.Event.KeyCode == Keycode.Enter)
                || (e.ActionId == ImeAction.Done && e.Event == null)
                || (e.ActionId == ImeAction.ImeNull && e.Event == null))
            {
                Save();
            }
        }

        private void Save()
        {
            using (var waitHelper = new WaitHelper(this.Activity, "Updating Line Item"))
            {
                // close the on-screen keyboard
                var inputMethodManager = (InputMethodManager)this.Activity.GetSystemService(Context.InputMethodService);
                inputMethodManager.HideSoftInputFromWindow(this.View.WindowToken, HideSoftInputFlags.None);

                // save the quantity on the order line
                LineItem.QtyOrdered = decimal.Parse(Quantity.Text);

                if (!ExistingLineItem)
                {
                    // add the order line to the order in memory
                    OrderDetails.LineItems.Add(LineItem);
                }

                // go to the line items screen
                FragmentManager.PopBackStack("LineItemsFragment", (int)App.PopBackStackFlags.Inclusive);
            }
        }

        public override void OnResume()
        {
            base.OnResume();

            var activity = this.Activity as MainActivity;
            if (activity != null)
            {
                activity.FragmentTitle = "Line Item Details";
            }
        }
    }
}