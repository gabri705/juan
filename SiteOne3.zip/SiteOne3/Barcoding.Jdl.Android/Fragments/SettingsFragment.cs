using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using Android.Support.V4.App;

using Android.Content;
using Android.OS;
using Android.Runtime;
using Android.Util;
using Android.Views;
using Android.Widget;
using Barcoding.Jdl.Android.Activities;
using Android.Views.InputMethods;

namespace Barcoding.Jdl.Android.Fragments
{
    public class SettingsFragment : Fragment
    {
        private Button ClearHomeBranchSettingButton;
        private TextView HomeBranchName;
        private TextView HomeBranchNumber;
        private EditText DefaultDomain;
        
        public override View OnCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState)
        {
            var view = inflater.Inflate(Resource.Layout.SettingsFragment, null);

            ClearHomeBranchSettingButton = view.FindViewById<Button>(Resource.Id.ClearHomeBranchSettingButton);
            HomeBranchName = view.FindViewById<TextView>(Resource.Id.HomeBranchName);
            HomeBranchNumber = view.FindViewById<TextView>(Resource.Id.HomeBranchNumber);
            DefaultDomain = view.FindViewById<EditText>(Resource.Id.DefaultDomain);

            ClearHomeBranchSettingButton.Click += ClearHomeBranchSettingButton_Click;
            
            using (var settings = this.Activity.GetSharedPreferences("JdlSettings", FileCreationMode.Private))
            {
                HomeBranchName.Text = settings.GetString("HomeBranchName", "");
                HomeBranchNumber.Text = settings.GetString("HomeBranchNumber", "");
                DefaultDomain.Text = settings.GetString("DefaultDomain", "jdl");
            }

            DefaultDomain.EditorAction += DefaultDomain_EditorAction;
            
            return view;
        }

        private void DefaultDomain_EditorAction(object sender, TextView.EditorActionEventArgs e)
        {
            if ((e.ActionId == ImeAction.ImeNull && e.Event != null && e.Event.Action == KeyEventActions.Up && e.Event.KeyCode == Keycode.Enter)
                || (e.ActionId == ImeAction.Done && e.Event == null)
                || (e.ActionId == ImeAction.ImeNull && e.Event == null))
            {
                using (var settings = this.Activity.GetSharedPreferences("JdlSettings", FileCreationMode.Private))
                using (var editor = settings.Edit())
                {
                    editor.PutString("DefaultDomain", DefaultDomain.Text.Trim());

                    editor.Commit();

                    Toast.MakeText(this.Activity, "Setting Saved", ToastLength.Short).Show();
                }
            }
        }

        private void ClearHomeBranchSettingButton_Click(object sender, EventArgs e)
        {
            var dialog = new global::Android.App.AlertDialog.Builder(this.Activity);
            dialog.SetTitle("Clear Setting");
            dialog.SetMessage("Are you sure you want to clear this setting?");
            dialog.SetPositiveButton("Yes", (s, args) =>
            {
                using (var settings = this.Activity.GetSharedPreferences("JdlSettings", FileCreationMode.Private))
                using (var editor = settings.Edit())
                {
                    editor.Remove("HomeBranchSupplyChainNodeId");
                    editor.Remove("HomeBranchName");
                    editor.Remove("HomeBranchNumber");
                    editor.Commit();

                    HomeBranchName.Text = "";
                    HomeBranchNumber.Text = "";
                }
            });
            dialog.SetNegativeButton("No", (s, args) => { });
            dialog.SetCancelable(false);
            dialog.Show();
        }

        public override void OnResume()
        {
            base.OnResume();

            var activity = this.Activity as MainActivity;
            if (activity != null)
            {
                activity.FragmentTitle = "Settings";
            }
        }
    }
}